import { useState, useEffect } from "react";
import { StoreProvider, useStore } from "./state/store";
import Onboarding from "./components/Onboarding";
import BottomNav from "./components/BottomNav";
import Workspace from "./components/Workspace";
import CreateScreen from "./components/CreateScreen";
import MemoryScreen from "./components/MemoryScreen";
import ProfileScreen from "./components/ProfileScreen";
import ToolsScreen from "./components/ToolsScreen";
import LiveWorldScreen from "./components/LiveWorldScreen";

function WelcomeBanner({ user }: { user: { name: string; email: string } | null }) {
  const [show, setShow] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => setShow(false), 5000);
    return () => clearTimeout(timer);
  }, []);
  
  if (!show || !user) return null;
  
  return (
    <div className="fixed top-4 left-4 right-4 z-50 glass-strong rounded-2xl p-4 anim-slide-up flex items-center justify-between">
      <div className="flex items-center gap-3">
        <span className="text-2xl">🫶</span>
        <div>
          <p className="text-sm font-semibold">Hey {user.name}, welcome to My Synex!</p>
          <p className="text-xs text-[#8a8a93]">Ready to explore, create, and learn?</p>
        </div>
      </div>
      <button onClick={() => setShow(false)} className="text-[#8a8a93] hover:text-white p-1">✕</button>
    </div>
  );
}

// Subtle parallax effect that doesn't block interactions
function useParallax() {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    let rafId: number;
    const handleMouseMove = (e: MouseEvent) => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const x = (window.innerWidth / 2 - e.clientX) / 100;
        const y = (window.innerHeight / 2 - e.clientY) / 100;
        setTilt({ x: Math.max(-3, Math.min(3, x)), y: Math.max(-3, Math.min(3, y)) });
      });
    };
    
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      cancelAnimationFrame(rafId);
    };
  }, []);
  
  return tilt;
}

function Shell() {
  const { showOnboarding, tab, focusMode, user } = useStore();
  const tilt = useParallax();

  if (showOnboarding) return <Onboarding />;

  return (
    <div 
      className="bg-scene h-dvh flex flex-col overflow-hidden"
      style={{ 
        perspective: "1000px",
      }}
    >
      <div 
        className="flex flex-col h-full w-full"
        style={{ 
          transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${-tilt.x}deg)`,
          transformStyle: "preserve-3d",
        }}
      >
        <WelcomeBanner user={user} />
        <main className="flex-1 min-h-0 flex flex-col overflow-hidden">
          {tab === "workspace" && <Workspace />}
          {tab === "create" && <CreateScreen />}
          {tab === "world" && <LiveWorldScreen />}
          {tab === "memory" && <MemoryScreen />}
          {tab === "tools" && <ToolsScreen />}
          {tab === "profile" && <ProfileScreen />}
        </main>
        {!focusMode && <BottomNav />}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
