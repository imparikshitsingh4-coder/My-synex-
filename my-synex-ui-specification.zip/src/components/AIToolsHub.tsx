import { useState } from "react";
import { INTELLIGENCE_TOOLS, CODING_TOOLS, CREATIVE_TEXT_TOOLS, runAiTool, type ToolConfig } from "../data/aiTools";

function ToolRunner({ tool, onBack }: { tool: ToolConfig; onBack: () => void }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const run = async () => {
    const val = input.trim() || tool.placeholder;
    setLoading(true);
    setResult(null);
    const text = await runAiTool(tool, val);
    setResult(text);
    setLoading(false);
  };

  return (
    <div className="anim-slide-up">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4">
        ← Back to Tools
      </button>

      <div className="glass card-glow rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">{tool.icon}</span>
          <div>
            <h2 className="text-lg font-bold">{tool.title}</h2>
            <p className="text-[11px] text-[#8a8a93]">{tool.desc}</p>
          </div>
        </div>

        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={tool.placeholder}
          rows={3}
          className="w-full glass rounded-xl px-4 py-3 text-sm outline-none bg-white/5 border border-white/10 focus:border-purple-400/40 resize-none mb-3"
        />

        <button
          onClick={run}
          disabled={loading}
          className="grad-btn w-full rounded-xl py-3 font-semibold text-sm disabled:opacity-50"
        >
          {loading ? "Thinking..." : `Run ${tool.title}`}
        </button>
      </div>

      {loading && (
        <div className="glass rounded-2xl p-6 text-center anim-fade">
          <div className="flex justify-center gap-1.5 mb-2">
            {[0, 1, 2].map((i) => (
              <span key={i} className="w-2 h-2 rounded-full bg-purple-400 typing-dot" style={{ animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
          <p className="text-xs text-[#8a8a93]">Processing in real time...</p>
        </div>
      )}

      {result && (
        <div className="glass card-glow rounded-2xl p-5 anim-slide-up">
          <div className="text-[10px] tracking-[0.25em] text-cyan-300/80 font-semibold mb-3">
            RESULT
          </div>
          {tool.outputStyle === "code" ? (
            <pre className="text-[12px] font-mono text-emerald-300 whitespace-pre-wrap leading-relaxed overflow-x-auto bg-black/30 rounded-xl p-4">
              {result}
            </pre>
          ) : (
            <p className="text-[14px] leading-relaxed text-white/85 whitespace-pre-line">
              {result}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

const CATEGORIES = [
  { id: "intelligence" as const, label: "Intelligence", icon: "🧠", tools: INTELLIGENCE_TOOLS, color: "from-purple-500/20 to-indigo-500/20" },
  { id: "coding" as const, label: "Coding", icon: "💻", tools: CODING_TOOLS, color: "from-amber-500/20 to-orange-500/20" },
  { id: "creative" as const, label: "Creative", icon: "🎨", tools: CREATIVE_TEXT_TOOLS, color: "from-pink-500/20 to-rose-500/20" },
];

export default function AIToolsHub({ initialCategory }: { initialCategory?: "intelligence" | "coding" | "creative" }) {
  const [category, setCategory] = useState<"intelligence" | "coding" | "creative">(initialCategory || "intelligence");
  const [activeTool, setActiveTool] = useState<ToolConfig | null>(null);

  if (activeTool) {
    return (
      <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
        <ToolRunner tool={activeTool} onBack={() => setActiveTool(null)} />
      </div>
    );
  }

  const currentCat = CATEGORIES.find((c) => c.id === category)!;

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-purple-300/80 font-semibold mb-1">
            AI TOOLS SUITE
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Power Tools</h1>
        </div>
      </div>

      {/* Category tabs */}
      <div className="glass rounded-2xl p-1 grid grid-cols-3 gap-1 mb-4">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={`flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold transition-all duration-300 ${
              category === c.id
                ? "bg-gradient-to-r from-purple-600/70 to-indigo-600/70 text-white shadow-[0_0_20px_rgba(139,92,246,0.35)]"
                : "text-[#8a8a93] hover:text-white"
            }`}
          >
            <span>{c.icon}</span> {c.label}
          </button>
        ))}
      </div>

      <div className="text-[11px] text-[#8a8a93] mb-3">{currentCat.tools.length} tools available · real time AI</div>

      <div className="grid grid-cols-2 gap-3">
        {currentCat.tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => setActiveTool(tool)}
            className="glass card-glow rounded-2xl p-4 text-left hover:bg-white/8 transition-all group"
          >
            <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${currentCat.color} flex items-center justify-center text-lg mb-2.5 group-hover:scale-110 transition-transform`}>
              {tool.icon}
            </div>
            <div className="text-[12.5px] font-semibold mb-0.5 leading-tight">{tool.title}</div>
            <div className="text-[10px] text-[#8a8a93] leading-snug">{tool.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
