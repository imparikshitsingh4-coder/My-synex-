import { useStore, type Tab } from "../state/store";
import { IconChat, IconSparkles, IconTrend, IconUser } from "./icons";

// Simple globe icon
const IconWorld = (p: any) => (
  <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="9" />
    <path d="M3.6 9h16.8M3.6 15h16.8M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" />
  </svg>
);

const TABS: { id: Tab; label: string; Icon: typeof IconChat }[] = [
  { id: "workspace", label: "Workspace", Icon: IconChat },
  { id: "create", label: "Create", Icon: IconSparkles },
  { id: "world", label: "World", Icon: IconWorld as any },
  { id: "memory", label: "Memory", Icon: IconTrend },
  { id: "tools", label: "Tools", Icon: IconUser },
  { id: "profile", label: "Profile", Icon: IconUser },
];

export default function BottomNav() {
  const { tab, setTab } = useStore();
  return (
    <nav className="sticky bottom-0 z-40 glass-strong border-t border-white/10">
      <div className="max-w-5xl mx-auto grid grid-cols-6 px-2 pb-[max(env(safe-area-inset-bottom),6px)] pt-1.5">
        {TABS.map(({ id, label, Icon }) => {
          const active = tab === id;
          return (
            <button
              key={id}
              onClick={() => setTab(id)}
              className="flex flex-col items-center gap-1 py-1.5 group"
            >
              <span
                className={`relative flex items-center justify-center w-11 h-7 rounded-full transition-all duration-300 ${
                  active
                    ? "bg-gradient-to-r from-purple-500/30 to-cyan-400/20"
                    : "group-hover:bg-white/5"
                }`}
              >
                <Icon
                  size={20}
                  className={`transition-colors duration-300 ${
                    active
                      ? "text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]"
                      : "text-[#8a8a93] group-hover:text-white/80"
                  }`}
                />
              </span>
              <span
                className={`text-[10px] font-medium tracking-wide transition-colors duration-300 ${
                  active ? "text-white" : "text-[#8a8a93]"
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
