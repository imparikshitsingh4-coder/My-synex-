import { useMemo } from "react";
import { useStore } from "../state/store";

interface Star {
  id: string;
  x: number;
  y: number;
  size: number;
  brightness: number;
  topic: string;
  connections: string[];
}

export default function Constellation() {
  const { messages, artifacts } = useStore();

  const stars = useMemo(() => {
    const generated: Star[] = [];
    const topics = new Map<string, number>();
    
    // Extract topics from messages
    messages.forEach((msg, idx) => {
      const words = msg.text.toLowerCase().split(/\s+/);
      words.forEach(word => {
        if (word.length > 5 && !["about", "would", "could", "should", "there", "their", "where"].includes(word)) {
          topics.set(word, (topics.get(word) || 0) + 1);
        }
      });
      
      // Create a star for this message
      if (idx % 3 === 0) {
        generated.push({
          id: `msg-${idx}`,
          x: 10 + Math.random() * 80,
          y: 10 + Math.random() * 80,
          size: 2 + Math.min(6, topics.size / 5),
          brightness: 0.4 + Math.random() * 0.6,
          topic: msg.role === "user" ? "Your Question" : "Synex Response",
          connections: [],
        });
      }
    });

    // Add stars for artifacts
    artifacts.forEach((art, idx) => {
      generated.push({
        id: `art-${idx}`,
        x: 15 + Math.random() * 70,
        y: 15 + Math.random() * 70,
        size: 4 + Math.random() * 4,
        brightness: 0.8,
        topic: art.kind === "image" ? "Image Created" : "Video Created",
        connections: generated.length > 0 ? [generated[Math.floor(Math.random() * generated.length)].id] : [],
      });
    });

    // Ensure minimum stars
    while (generated.length < 20) {
      generated.push({
        id: `auto-${generated.length}`,
        x: 5 + Math.random() * 90,
        y: 5 + Math.random() * 90,
        size: 1 + Math.random() * 3,
        brightness: 0.3 + Math.random() * 0.4,
        topic: "Knowledge Node",
        connections: generated.length > 0 ? [generated[Math.floor(Math.random() * generated.length)].id] : [],
      });
    }

    // Add connections between nearby stars
    generated.forEach((star, i) => {
      generated.slice(i + 1).forEach((other) => {
        const dist = Math.sqrt(Math.pow(star.x - other.x, 2) + Math.pow(star.y - other.y, 2));
        if (dist < 25 && Math.random() > 0.5) {
          star.connections.push(other.id);
        }
      });
    });

    return generated;
  }, [messages.length, artifacts.length]);

  const connections = useMemo(() => {
    const lines: { x1: number; y1: number; x2: number; y2: number; opacity: number }[] = [];
    stars.forEach(star => {
      star.connections.forEach(connId => {
        const target = stars.find(s => s.id === connId);
        if (target) {
          lines.push({
            x1: star.x,
            y1: star.y,
            x2: target.x,
            y2: target.y,
            opacity: Math.min(star.brightness, target.brightness) * 0.5,
          });
        }
      });
    });
    return lines;
  }, [stars]);

  const knowledgeLevel = Math.min(100, (messages.length + artifacts.length * 2) * 2);

  return (
    <div className="glass card-glow rounded-3xl p-6 relative overflow-hidden" style={{ minHeight: "400px" }}>
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1f] to-[#000]" />
      
      {/* Header */}
      <div className="relative z-10 mb-4">
        <div className="text-[10px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-1">
          AI CONSTELLATION
        </div>
        <h2 className="text-xl font-bold">Your Knowledge Galaxy</h2>
        <p className="text-xs text-[#8a8a93] mt-1">
          {messages.length} conversations · {artifacts.length} creations · {knowledgeLevel}% galaxy formed
        </p>
      </div>

      {/* Constellation canvas */}
      <div className="relative w-full h-80">
        {/* Connection lines */}
        <svg className="absolute inset-0 w-full h-full">
          {connections.map((line, i) => (
            <line
              key={i}
              x1={`${line.x1}%`}
              y1={`${line.y1}%`}
              x2={`${line.x2}%`}
              y2={`${line.y2}%`}
              stroke="rgba(34, 211, 238, 0.3)"
              strokeWidth="1"
              opacity={line.opacity}
            />
          ))}
        </svg>

        {/* Stars */}
        {stars.map((star) => (
          <div
            key={star.id}
            className="constellation-star cursor-pointer group"
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
              width: `${star.size * 2}px`,
              height: `${star.size * 2}px`,
              opacity: star.brightness,
              animationDelay: `${Math.random() * 2}s`,
            }}
            title={star.topic}
          >
            {/* Tooltip */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 glass rounded text-[10px] whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
              {star.topic}
            </div>
          </div>
        ))}

        {/* Center glow */}
        <div 
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full opacity-20"
          style={{
            background: `radial-gradient(circle, rgba(34, 211, 238, ${knowledgeLevel / 100}) 0%, transparent 70%)`,
          }}
        />
      </div>

      {/* Stats */}
      <div className="relative z-10 grid grid-cols-3 gap-3 mt-4">
        <div className="glass rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-cyan-300">{messages.length}</div>
          <div className="text-[10px] text-[#8a8a93]">Conversations</div>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-purple-300">{artifacts.length}</div>
          <div className="text-[10px] text-[#8a8a93]">Creations</div>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-emerald-300">{stars.length}</div>
          <div className="text-[10px] text-[#8a8a93]">Knowledge Stars</div>
        </div>
      </div>

      {/* Growth message */}
      <p className="relative z-10 text-xs text-center text-[#8a8a93] mt-4">
        Keep learning and creating to expand your galaxy.
      </p>
    </div>
  );
}
