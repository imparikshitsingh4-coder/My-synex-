import { useState } from "react";

interface Lesson {
  id: number;
  title: string;
  content: string;
  notes: string;
  tricks: string;
  completed: boolean;
  quiz: { question: string; options: string[]; answer: number };
}

interface Course {
  topic: string;
  lessons: Lesson[];
  currentLesson: number;
}

export default function CourseGenerator() {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [course, setCourse] = useState<Course | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [activeTab, setActiveTab] = useState<"content" | "notes" | "tricks">("content");

  const generateCourse = async () => {
    if (!topic.trim()) return;
    setLoading(true);

    const query = `Create a complete 30-lesson course on "${topic}". For each lesson, provide:

Lesson [Number]: [Title]

CONTENT:
[2-3 detailed paragraphs explaining the concept with examples]

NOTES:
[Key points to remember, definitions, and summary]

TRICKS:
[Memory aids, shortcuts, pro tips, and common pitfalls to avoid]

QUIZ:
Question: [Multiple choice question]
A) [Option 1]
B) [Option 2]
C) [Option 3]
D) [Option 4]
Answer: [Letter]

---

Make it progressive from beginner to advanced. Each lesson should build on previous ones.`;

    try {
      const res = await fetch(`https://text.pollinations.ai/${encodeURIComponent(query)}?system=${encodeURIComponent("You are an expert curriculum designer. Create engaging, practical lessons with clear structure. Use natural language without asterisks or special formatting characters.")}`);
      let text = await res.text();
      text = text.replace(/[:_\-*~`#]/g, '');
      
      // Parse the course content
      const lessons: Lesson[] = [];
      const lessonBlocks = text.split(/Lesson\s*\d+:|LESSON\s*\d+:/i).filter(block => block.trim());
      
      lessonBlocks.forEach((block, index) => {
        const lines = block.trim().split('\n').filter(l => l.trim());
        if (lines.length < 3) return;
        
        const title = lines[0].trim();
        
        // Extract sections
        let content = "";
        let notes = "";
        let tricks = "";
        let quizQuestion = "";
        let quizOptions: string[] = [];
        let quizAnswer = 0;
        
        let currentSection = "content";
        
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          
          if (line.toUpperCase().includes("CONTENT") || line.toUpperCase().includes("CONTENT:")) {
            currentSection = "content";
            continue;
          } else if (line.toUpperCase().includes("NOTES") || line.toUpperCase().includes("NOTES:")) {
            currentSection = "notes";
            continue;
          } else if (line.toUpperCase().includes("TRICKS") || line.toUpperCase().includes("TRICKS:")) {
            currentSection = "tricks";
            continue;
          } else if (line.toUpperCase().includes("QUIZ") || line.toUpperCase().includes("QUIZ:")) {
            currentSection = "quiz";
            continue;
          }
          
          if (currentSection === "content") {
            content += line + " ";
          } else if (currentSection === "notes") {
            notes += line + " ";
          } else if (currentSection === "tricks") {
            tricks += line + " ";
          } else if (currentSection === "quiz") {
            if (line.toUpperCase().startsWith("QUESTION:")) {
              quizQuestion = line.replace(/question:/i, "").trim();
            } else if (/^[A-D][).:]/.test(line)) {
              quizOptions.push(line.replace(/^[A-D][).:]\s*/, "").trim());
            } else if (line.toUpperCase().includes("ANSWER:")) {
              const answerMatch = line.match(/([A-D])/);
              if (answerMatch) {
                quizAnswer = answerMatch[1].charCodeAt(0) - 65;
              }
            }
          }
        }
        
        lessons.push({
          id: index + 1,
          title: title || `Lesson ${index + 1}`,
          content: content.trim() || "Content being generated...",
          notes: notes.trim() || "Key points will appear here...",
          tricks: tricks.trim() || "Tips and tricks coming soon...",
          completed: false,
          quiz: {
            question: quizQuestion || `What did you learn in this lesson about ${topic}?`,
            options: quizOptions.length === 4 ? quizOptions : [
              "The fundamental concept",
              "An advanced technique", 
              "A common misconception",
              "An unrelated topic"
            ],
            answer: quizAnswer
          }
        });
      });

      // Ensure we have 30 lessons
      while (lessons.length < 30) {
        const lessonNum = lessons.length + 1;
        lessons.push({
          id: lessonNum,
          title: `Lesson ${lessonNum}: Advanced ${topic} Concepts`,
          content: `This lesson covers advanced topics in ${topic}. As you progress through the course, the concepts become more sophisticated and practical.`,
          notes: `Focus on understanding the core principles before moving to advanced topics.`,
          tricks: `Practice regularly and apply concepts to real-world scenarios for better retention.`,
          completed: false,
          quiz: {
            question: `What is the most important aspect of mastering ${topic}?`,
            options: [
              "Consistent practice and application",
              "Reading theory without practice",
              "Skipping fundamental concepts",
              "Memorizing without understanding"
            ],
            answer: 0
          }
        });
      }

      setCourse({
        topic: topic,
        lessons: lessons.slice(0, 30),
        currentLesson: 0,
      });
    } catch {
      // Fallback course
      setCourse({
        topic: topic,
        lessons: Array.from({ length: 30 }, (_, i) => ({
          id: i + 1,
          title: `Lesson ${i + 1}: ${topic} ${i < 10 ? "Basics" : i < 20 ? "Intermediate" : "Advanced"}`,
          content: `Welcome to Lesson ${i + 1} of your ${topic} course. This lesson covers essential concepts that build your understanding progressively.`,
          notes: `Key takeaways: Focus on fundamentals. Practice daily. Review previous lessons.`,
          tricks: `Pro tip: Apply what you learn immediately. Teach others to solidify your understanding.`,
          completed: false,
          quiz: {
            question: `What is the best way to learn ${topic}?`,
            options: [
              "Consistent practice and real application",
              "Passive reading only",
              "Cramming before tests",
              "Skipping difficult topics"
            ],
            answer: 0
          }
        })),
        currentLesson: 0,
      });
    }
    
    setLoading(false);
  };

  const completeLesson = () => {
    if (!course) return;
    const updated = { ...course };
    updated.lessons[course.currentLesson].completed = true;
    setCourse(updated);
    setShowQuiz(true);
    setActiveTab("content");
  };

  const nextLesson = () => {
    if (!course) return;
    setShowQuiz(false);
    setQuizAnswer(null);
    setShowResults(false);
    setActiveTab("content");
    setCourse({ ...course, currentLesson: Math.min(course.currentLesson + 1, course.lessons.length - 1) });
  };

  const progress = course ? (course.lessons.filter(l => l.completed).length / course.lessons.length) * 100 : 0;

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-violet-300/80 font-semibold mb-1">
            INSTANT COURSES
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Course Generator</h1>
        </div>
      </div>

      {!course ? (
        <div className="anim-fade">
          <div className="glass card-glow rounded-2xl p-6 mb-4">
            <div className="text-4xl mb-4">🎓</div>
            <h2 className="text-lg font-bold mb-2">What do you want to learn?</h2>
            <p className="text-sm text-[#8a8a93] mb-5">
              Synex will create a complete 30-lesson course with detailed content, study notes, pro tricks, and quizzes.
            </p>
            <div className="flex gap-2">
              <input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && generateCourse()}
                placeholder="e.g., Machine Learning, Guitar, Spanish..."
                className="flex-1 glass rounded-xl px-4 py-3 text-sm outline-none bg-white/5 border border-white/10 focus:border-violet-400/40"
              />
              <button
                onClick={generateCourse}
                disabled={loading || !topic.trim()}
                className="grad-btn rounded-xl px-6 py-3 font-semibold text-sm disabled:opacity-40 disabled:pointer-events-none"
              >
                {loading ? "Creating..." : "Generate"}
              </button>
            </div>
          </div>

          <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
            POPULAR TOPICS
          </div>
          <div className="flex flex-wrap gap-2">
            {["Python Programming", "Digital Marketing", "Photography", "Data Science", "Creative Writing", "French Language", "Web Development", "Personal Finance"].map((t) => (
              <button
                key={t}
                onClick={() => { setTopic(t); generateCourse(); }}
                className="glass rounded-full px-4 py-2 text-xs text-white/80 hover:bg-white/10 hover:text-violet-200 transition-all"
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="anim-slide-up">
          <button
            onClick={() => setCourse(null)}
            className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4"
          >
            ← Back to Topics
          </button>

          {/* Progress */}
          <div className="glass rounded-2xl p-4 mb-4">
            <div className="flex justify-between text-xs mb-2">
              <span className="font-semibold">{course.topic}</span>
              <span className="text-violet-300">{course.lessons.filter(l => l.completed).length}/30 Lessons</span>
            </div>
            <div className="h-2 rounded-full bg-white/8 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 to-purple-400 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Lesson */}
          {!showQuiz ? (
            <div className="glass card-glow rounded-2xl overflow-hidden">
              {/* Tab Navigation */}
              <div className="flex border-b border-white/10">
                {["content", "notes", "tricks"].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 py-3 text-xs font-semibold capitalize transition-all ${
                      activeTab === tab
                        ? "bg-violet-500/20 text-violet-200 border-b-2 border-violet-400"
                        : "text-[#8a8a93] hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {tab === "content" && "📖 Lesson"}
                    {tab === "notes" && "📝 Notes"}
                    {tab === "tricks" && "💡 Tricks"}
                  </button>
                ))}
              </div>

              {/* Content Area */}
              <div className="p-5">
                <div className="text-[10px] tracking-[0.25em] text-violet-300/80 font-semibold mb-2">
                  LESSON {course.currentLesson + 1} OF 30
                </div>
                <h2 className="text-lg font-bold mb-4">{course.lessons[course.currentLesson].title}</h2>
                
                {activeTab === "content" && (
                  <p className="text-[14px] leading-relaxed text-white/85 whitespace-pre-line">
                    {course.lessons[course.currentLesson].content}
                  </p>
                )}
                
                {activeTab === "notes" && (
                  <div className="glass rounded-xl p-4 bg-yellow-500/5 border border-yellow-500/20">
                    <div className="text-xs text-yellow-300 font-semibold mb-2">📚 Key Points to Remember</div>
                    <p className="text-[14px] leading-relaxed text-white/85">
                      {course.lessons[course.currentLesson].notes}
                    </p>
                  </div>
                )}
                
                {activeTab === "tricks" && (
                  <div className="glass rounded-xl p-4 bg-cyan-500/5 border border-cyan-500/20">
                    <div className="text-xs text-cyan-300 font-semibold mb-2">🎯 Pro Tips & Tricks</div>
                    <p className="text-[14px] leading-relaxed text-white/85">
                      {course.lessons[course.currentLesson].tricks}
                    </p>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="p-5 pt-0 flex gap-3">
                <button
                  onClick={completeLesson}
                  className="grad-btn flex-1 rounded-xl py-3 font-semibold text-sm"
                >
                  Complete Lesson & Take Quiz
                </button>
                {course.currentLesson > 0 && (
                  <button
                    onClick={() => setCourse({ ...course, currentLesson: course.currentLesson - 1 })}
                    className="glass rounded-xl px-4 py-3 text-xs hover:bg-white/10"
                  >
                    Prev
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="glass card-glow rounded-2xl p-5">
              <div className="text-[10px] tracking-[0.25em] text-amber-300/80 font-semibold mb-2">
                🧠 KNOWLEDGE CHECK
              </div>
              <h3 className="text-[15px] font-semibold mb-4">{course.lessons[course.currentLesson].quiz.question}</h3>
              <div className="space-y-2 mb-5">
                {course.lessons[course.currentLesson].quiz.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setQuizAnswer(i)}
                    className={`w-full text-left rounded-xl px-4 py-3 text-sm transition-all ${
                      quizAnswer === i
                        ? "bg-violet-500/30 border border-violet-400/50"
                        : "glass hover:bg-white/10"
                    }`}
                  >
                    {String.fromCharCode(65 + i)}. {opt}
                  </button>
                ))}
              </div>
              {quizAnswer !== null && (
                <button
                  onClick={() => setShowResults(true)}
                  className="grad-btn w-full rounded-xl py-3 font-semibold text-sm"
                >
                  Check Answer
                </button>
              )}
              {showResults && (
                <div className="mt-4 p-4 rounded-xl bg-white/5 text-center">
                  {quizAnswer === course.lessons[course.currentLesson].quiz.answer ? (
                    <>
                      <div className="text-2xl mb-2">✅</div>
                      <p className="text-emerald-300 font-semibold">Correct! Great job.</p>
                      <button onClick={nextLesson} className="grad-btn rounded-xl px-6 py-2 text-xs mt-3">Next Lesson →</button>
                    </>
                  ) : (
                    <>
                      <div className="text-2xl mb-2">❌</div>
                      <p className="text-red-300 font-semibold">Not quite. The answer was {String.fromCharCode(65 + course.lessons[course.currentLesson].quiz.answer)}.</p>
                      <button onClick={nextLesson} className="glass rounded-xl px-6 py-2 text-xs mt-3 hover:bg-white/10">Continue Anyway →</button>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Lesson Navigator */}
          <div className="glass rounded-2xl p-4 mt-4">
            <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
              ALL LESSONS
            </div>
            <div className="grid grid-cols-6 gap-2">
              {course.lessons.map((lesson, i) => (
                <button
                  key={lesson.id}
                  onClick={() => {
                    setCourse({ ...course, currentLesson: i });
                    setShowQuiz(false);
                    setQuizAnswer(null);
                    setShowResults(false);
                    setActiveTab("content");
                  }}
                  className={`aspect-square rounded-lg flex items-center justify-center text-xs font-semibold transition-all ${
                    i === course.currentLesson
                      ? "bg-violet-500 text-white"
                      : lesson.completed
                      ? "bg-emerald-500/30 text-emerald-300"
                      : "glass text-[#8a8a93] hover:bg-white/10"
                  }`}
                >
                  {lesson.completed ? "✓" : i + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
