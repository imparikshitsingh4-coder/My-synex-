import { useState, useRef, useEffect } from "react";
import { useStore } from "../state/store";
import { IconBolt, IconImage, IconVideo, IconPlay } from "./icons";

const PLACEHOLDERS = {
  image: "A cyberpunk cat DJing in Tokyo, neon rain, 4k",
  video: "A rocket taking off from Mars orbit, cinematic wide angle",
};

export default function CreateScreen() {
  const {
    addArtifact,
    artifacts,
    canImage,
    canVideo,
    imagesLeft,
    videosLeft,
    tier,
    setTab,
  } = useStore();
  const [mode, setMode] = useState<"image" | "video">("image");
  const [prompt, setPrompt] = useState("");
  const [rendering, setRendering] = useState(false);
  const [progress, setProgress] = useState(0);
  const [renderStage, setRenderStage] = useState("");
  const [lightbox, setLightbox] = useState<{ src: string; kind: "image" | "video" } | null>(null);
  const [videoFrames, setVideoFrames] = useState<string[]>([]);
  const [videoPlaying, setVideoPlaying] = useState(false);
  const videoFrameRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);

  const modelTag = mode === "image" ? "Nano Banana" : "Sora 2";
  const allowed = mode === "image" ? canImage : canVideo;
  const left = mode === "image" ? imagesLeft : videosLeft;

  // Load all image sources for video animation
  const [loadedFrames, setLoadedFrames] = useState<HTMLImageElement[]>([]);
  
  useEffect(() => {
    if (videoFrames.length > 0 && videoPlaying) {
      const images: HTMLImageElement[] = [];
      let loaded = 0;
      videoFrames.forEach((src) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          loaded++;
          if (loaded === videoFrames.length) {
            setLoadedFrames(images);
          }
        };
        img.src = src;
        images.push(img);
      });
    }
  }, [videoFrames, videoPlaying]);

  // Animate video frames on canvas
  useEffect(() => {
    if (!videoPlaying || loadedFrames.length === 0) {
      cancelAnimationFrame(animFrameRef.current);
      return;
    }

    const canvas = videoFrameRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = 800;
    canvas.height = 450;

    let frameIndex = 0;
    const frameRate = 3;
    let startTime = 0;

    const animate = (time: number) => {
      if (!startTime) startTime = time;
      const elapsed = (time - startTime) / 1000;
      
      // Switch frame every 2 seconds
      const newFrameIndex = Math.floor(elapsed * frameRate) % loadedFrames.length;
      
      if (newFrameIndex !== frameIndex) {
        frameIndex = newFrameIndex;
        const img = loadedFrames[frameIndex];
        
        // Ken Burns effect
        const scale = 1.1 + Math.sin(elapsed * 0.3) * 0.05;
        const offsetX = Math.sin(elapsed * 0.2) * 20;
        const offsetY = Math.cos(elapsed * 0.25) * 15;
        
        ctx.save();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw with Ken Burns
        const sw = canvas.width * scale;
        const sh = canvas.height * scale;
        const sx = (canvas.width - sw) / 2 + offsetX;
        const sy = (canvas.height - sh) / 2 + offsetY;
        
        ctx.drawImage(img, sx, sy, sw, sh);
        
        // Film grain overlay
        ctx.globalAlpha = 0.03;
        ctx.fillStyle = "#fff";
        for (let i = 0; i < 500; i++) {
          const x = Math.random() * canvas.width;
          const y = Math.random() * canvas.height;
          ctx.fillRect(x, y, 1, 1);
        }
        ctx.globalAlpha = 1;
        
        // Vignette
        const gradient = ctx.createRadialGradient(
          canvas.width / 2, canvas.height / 2, canvas.height * 0.4,
          canvas.width / 2, canvas.height / 2, canvas.height * 1.2
        );
        gradient.addColorStop(0, "rgba(0,0,0,0)");
        gradient.addColorStop(1, "rgba(0,0,0,0.5)");
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.restore();
      }
      
      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);
    
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [videoPlaying, loadedFrames]);

  const render = async () => {
    if (rendering || !allowed) return;
    const p = prompt.trim() || PLACEHOLDERS[mode];
    setRendering(true);
    setProgress(0);
    setVideoFrames([]);
    setVideoPlaying(false);

    if (mode === "video") {
      // Generate 5 frames for video using different seeds
      const stages = [
        { progress: 10, text: "Analyzing scene composition…" },
        { progress: 25, text: "Generating keyframes (1/5)…" },
        { progress: 40, text: "Generating keyframes (2/5)…" },
        { progress: 55, text: "Generating keyframes (3/5)…" },
        { progress: 70, text: "Generating keyframes (4/5)…" },
        { progress: 85, text: "Generating keyframes (5/5)…" },
        { progress: 92, text: "Stitching frames into video…" },
        { progress: 97, text: "Applying cinematic color grading…" },
      ];

      const frames: string[] = [];
      
      for (let i = 0; i < 5; i++) {
        const seed = Math.floor(Math.random() * 10000) + i * 100;
        const enhancedPrompt = `${p}, cinematic shot ${i === 0 ? "wide angle" : i === 2 ? "medium shot" : i === 4 ? "close-up" : "dynamic camera movement"}, 8k, highly detailed, motion blur`;
        const frameUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?nologo=1&seed=${seed}&width=800&height=450`;
        
        // Simulate generation time
        await new Promise(r => setTimeout(r, 800));
        setProgress(stages[i * 2 + (i > 0 ? 1 : 0)]?.progress || ((i + 1) * 18));
        setRenderStage(stages[i * 2 + (i > 0 ? 1 : 0)]?.text || `Generating frame ${i + 1}…`);
        
        frames.push(frameUrl);
      }
      
      setVideoFrames(frames);
      setProgress(100);
      setRenderStage("Rendering complete!");
      
      await new Promise(r => setTimeout(r, 500));
      addArtifact("video", p);
      setVideoPlaying(true);
      setRendering(false);
      setProgress(0);
      setRenderStage("");
      setPrompt("");
    } else {
      // Image mode
      const stages = [
        { progress: 20, text: "Composing scene…" },
        { progress: 50, text: "Generating details…" },
        { progress: 80, text: "Applying finishing touches…" },
      ];
      
      for (const stage of stages) {
        await new Promise(r => setTimeout(r, 700));
        setProgress(stage.progress);
        setRenderStage(stage.text);
      }
      
      addArtifact("image", p);
      setRendering(false);
      setProgress(0);
      setRenderStage("");
      setPrompt("");
    }
  };

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-purple-300/80 font-semibold mb-1">
            CREATOR SUITE
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Generate</h1>
        </div>
        <span className="flex items-center gap-1.5 rounded-full border border-cyan-400/25 bg-cyan-400/8 px-3.5 py-1.5 text-xs text-cyan-200">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-300 pulse-dot" />
          {modelTag}
        </span>
      </div>

      {/* Mode toggle */}
      <div className="glass rounded-2xl p-1 grid grid-cols-2 gap-1 mb-4">
        {(["image", "video"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold capitalize transition-all duration-300 ${
              mode === m
                ? "bg-gradient-to-r from-purple-600/70 to-indigo-600/70 text-white shadow-[0_0_20px_rgba(139,92,246,0.35)]"
                : "text-[#8a8a93] hover:text-white"
            }`}
          >
            {m === "image" ? <IconImage size={16} /> : <IconVideo size={16} />}
            {m}
          </button>
        ))}
      </div>

      {/* Prompt */}
      <div className="glass rounded-2xl p-4 mb-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value.slice(0, 500))}
          placeholder={PLACEHOLDERS[mode]}
          rows={3}
          disabled={rendering}
          className="w-full bg-transparent outline-none resize-none text-[14px] placeholder:text-[#8a8a93]/60 disabled:opacity-50"
        />
        <div className="flex items-center justify-between mt-1">
          <span className="text-[11px] text-[#8a8a93]">
            {tier === "guest" ? "Guest" : "Free"} · {left === Infinity ? "∞" : left}{" "}
            {mode} render{left === 1 ? "" : "s"} left today
          </span>
          <span className="text-[11px] text-[#8a8a93] font-mono">
            {prompt.length}/500
          </span>
        </div>
      </div>

      {/* Render button */}
      <button
        onClick={render}
        disabled={rendering || !allowed}
        className="grad-btn w-full rounded-2xl py-3.5 font-semibold text-[15px] flex items-center justify-center gap-2 disabled:opacity-50 disabled:pointer-events-none"
      >
        <IconBolt size={18} className="text-white" />
        {rendering ? `${Math.round(progress)}% — ${renderStage}` : ` ${mode === "video" ? "Generate Video" : "Generate Image"}`}
      </button>

      {!allowed && (
        <div className="mt-3 glass rounded-2xl px-4 py-3 text-xs text-amber-300/90 flex items-center justify-between anim-fade">
          <span>
            Daily {mode} limit reached for {tier === "guest" ? "Guest Mode" : "Free tier"}.
          </span>
          {tier === "guest" && (
            <button
              onClick={() => setTab("profile")}
              className="text-cyan-300 font-semibold hover:underline shrink-0 ml-3"
            >
              Sign up →
            </button>
          )}
        </div>
      )}

      {rendering && (
        <div className="mt-4 glass rounded-2xl p-4 anim-fade">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-cyan-200">
              {modelTag} · {mode === "video" ? "compiling cinematic video" : "generating image"}
            </span>
            <span className="text-[#8a8a93] font-mono">{renderStage}</span>
          </div>
          <div className="h-2 rounded-full bg-white/8 overflow-hidden mb-3">
            <div
              className="h-full rounded-full bg-gradient-to-r from-purple-500 via-cyan-400 to-purple-500 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          {videoFrames.length > 0 ? (
            <div className="aspect-video rounded-xl overflow-hidden bg-black">
              <canvas
                ref={videoFrameRef}
                className="w-full h-full"
                width={800}
                height={450}
              />
            </div>
          ) : (
            <div className="aspect-video rounded-xl shimmer" />
          )}
        </div>
      )}

      {/* Gallery */}
      <div className="mt-6">
        <div className="text-[10px] tracking-[0.3em] text-[#8a8a93] font-semibold mb-3">
          ARTIFACT GALLERY
        </div>
        {artifacts.length === 0 && !rendering ? (
          <div className="glass rounded-2xl py-14 px-6 text-center">
            <div className="text-3xl mb-3 opacity-60">🗂️</div>
            <p className="text-sm text-[#8a8a93] max-w-xs mx-auto leading-relaxed">
              No artifacts yet. Prompt and press Render to spin up a fresh
              visual.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {artifacts.map((a) => (
              <button
                key={a.id}
                onClick={() => setLightbox({ src: a.src, kind: a.kind })}
                className="group relative rounded-2xl overflow-hidden border border-white/10 anim-pop text-left"
              >
                <img
                  src={a.src}
                  alt={a.prompt}
                  className="w-full aspect-square object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {a.kind === "video" && (
                  <span className="absolute inset-0 flex items-center justify-center">
                    <span className="w-11 h-11 rounded-full bg-black/50 backdrop-blur flex items-center justify-center border border-white/25 group-hover:scale-110 transition-transform">
                      <IconPlay size={20} className="text-white ml-0.5" />
                    </span>
                  </span>
                )}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 to-transparent p-2.5 pt-6">
                  <div className="text-[10px] text-cyan-300 font-semibold mb-0.5">
                    {a.model} · {a.kind.toUpperCase()}
                  </div>
                  <div className="text-[11px] text-white/85 line-clamp-2 leading-snug">
                    {a.prompt}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Video Player Lightbox */}
      {lightbox && lightbox.kind === "video" && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur flex items-center justify-center p-4 anim-fade"
          onClick={() => { setLightbox(null); setVideoPlaying(false); }}
        >
          <div className="relative w-full max-w-2xl" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightbox.src}
              alt="video artifact"
              className="w-full rounded-2xl border border-white/15 animate-[kenBurns_8s_ease-in-out_infinite_alternate]"
            />
            <style>{`
              @keyframes kenBurns {
                0% { transform: scale(1) translate(0, 0); }
                100% { transform: scale(1.12) translate(-2%, 1%); }
              }
            `}</style>
            <div className="absolute top-4 left-4 glass rounded-full px-3 py-1.5 text-xs text-cyan-200 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 pulse-dot" />
              PLAYING
            </div>
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-4 pt-12">
              <div className="text-sm text-white/80 font-medium">{lightbox.src.split('/prompt/')[1]?.split('?')[0]}</div>
              <div className="text-xs text-cyan-300 mt-1">Generated by {modelTag}</div>
            </div>
          </div>
        </div>
      )}

      {/* Image Lightbox */}
      {lightbox && lightbox.kind === "image" && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur flex items-center justify-center p-4 anim-fade"
          onClick={() => setLightbox(null)}
        >
          <img
            src={lightbox.src}
            alt="artifact"
            className="max-h-[85vh] max-w-full rounded-2xl border border-white/15 anim-pop"
          />
        </div>
      )}
    </div>
  );
}
