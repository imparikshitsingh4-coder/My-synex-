import { useState, useRef } from "react";
import { useStore } from "../state/store";

interface VisualTool {
  id: string;
  title: string;
  icon: string;
  desc: string;
  placeholder: string;
  promptTemplate: (input: string) => string;
  aspect: "square" | "landscape" | "portrait";
}

const VISUAL_TOOLS: VisualTool[] = [
  { id: "logo", title: "AI Logo", icon: "🔶", desc: "Generate brand logos", placeholder: "A minimalist fox logo for a tech startup", promptTemplate: (i) => `professional vector logo design, ${i}, clean minimal flat design, white background, high resolution`, aspect: "square" },
  { id: "banner", title: "AI Banner", icon: "🖼️", desc: "Web and social banners", placeholder: "A summer sale banner for an online store", promptTemplate: (i) => `web banner design, ${i}, modern graphic design, vibrant colors, professional marketing`, aspect: "landscape" },
  { id: "ui-design", title: "AI UI Design", icon: "📱", desc: "App and web UI mockups", placeholder: "A fitness tracking app home screen", promptTemplate: (i) => `modern mobile app UI design mockup, ${i}, clean interface, figma style, high fidelity`, aspect: "portrait" },
  { id: "poster", title: "AI Poster", icon: "🎪", desc: "Event and movie posters", placeholder: "A concert poster for an indie rock band", promptTemplate: (i) => `poster design, ${i}, bold typography, cinematic lighting, high quality print design`, aspect: "portrait" },
  { id: "illustration", title: "AI Illustration", icon: "🖌️", desc: "Custom digital illustrations", placeholder: "A cozy cabin in a snowy forest", promptTemplate: (i) => `beautiful digital illustration, ${i}, detailed artwork, vibrant color palette`, aspect: "landscape" },
  { id: "avatar", title: "AI Avatar", icon: "👤", desc: "Profile picture avatars", placeholder: "A friendly robot avatar with round eyes", promptTemplate: (i) => `portrait avatar icon, ${i}, digital art style, centered, clean background`, aspect: "square" },
  { id: "thumbnail", title: "AI Thumbnail", icon: "🎥", desc: "Video thumbnails", placeholder: "A shocked face reacting to a huge win, gaming video", promptTemplate: (i) => `youtube thumbnail design, ${i}, bold text overlay style, high contrast, eye catching`, aspect: "landscape" },
];

export default function CreativeStudio() {
  const { canImage, tier, setTab } = useStore();
  const [tool, setTool] = useState<VisualTool | null>(null);
  const [input, setInput] = useState("");
  const [rendering, setRendering] = useState(false);
  const [progress, setProgress] = useState(0);
  const [output, setOutput] = useState<string | null>(null);

  // Voiceover state
  const [voiceScript, setVoiceScript] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null);

  const render = async () => {
    if (!tool || rendering || !canImage) return;
    const val = input.trim() || tool.placeholder;
    setRendering(true);
    setProgress(0);
    setOutput(null);

    const stages = [15, 40, 65, 85, 100];
    for (const p of stages) {
      await new Promise((r) => setTimeout(r, 500));
      setProgress(p);
    }

    const dims = tool.aspect === "square" ? "800x800" : tool.aspect === "landscape" ? "900x500" : "500x900";
    const [w, h] = dims.split("x");
    const src = `https://image.pollinations.ai/prompt/${encodeURIComponent(tool.promptTemplate(val))}?nologo=1&seed=${Math.floor(Math.random() * 10000)}&width=${w}&height=${h}`;

    setOutput(src);
    setRendering(false);
  };

  const speak = () => {
    if (!voiceScript.trim()) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(voiceScript);
    utter.rate = 1;
    utter.pitch = 1;
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find((v) => v.lang.startsWith("en"));
    if (preferred) utter.voice = preferred;
    utter.onend = () => setSpeaking(false);
    utterRef.current = utter;
    setSpeaking(true);
    window.speechSynthesis.speak(utter);
  };

  const stopSpeak = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
  };

  if (tool) {
    return (
      <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
        <button onClick={() => { setTool(null); setOutput(null); setInput(""); }} className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4">
          ← Back to Creative Studio
        </button>

        <div className="glass card-glow rounded-2xl p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-3xl">{tool.icon}</span>
            <div>
              <h2 className="text-lg font-bold">{tool.title}</h2>
              <p className="text-[11px] text-[#8a8a93]">{tool.desc}</p>
            </div>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={tool.placeholder}
            rows={2}
            className="w-full glass rounded-xl px-4 py-3 text-sm outline-none bg-white/5 border border-white/10 focus:border-pink-400/40 resize-none mb-3"
          />
          <button
            onClick={render}
            disabled={rendering || !canImage}
            className="grad-btn w-full rounded-xl py-3 font-semibold text-sm disabled:opacity-50"
          >
            {rendering ? `Rendering ${progress}%` : `⚡ Generate ${tool.title.replace("AI ", "")}`}
          </button>
          {!canImage && (
            <div className="mt-3 text-xs text-amber-300 flex items-center justify-between">
              <span>Daily image limit reached for {tier}.</span>
              <button onClick={() => setTab("profile")} className="text-cyan-300 font-semibold hover:underline">Upgrade →</button>
            </div>
          )}
        </div>

        {rendering && (
          <div className="glass rounded-2xl p-4">
            <div className="h-2 rounded-full bg-white/8 overflow-hidden mb-3">
              <div className="h-full rounded-full bg-gradient-to-r from-pink-500 via-purple-400 to-pink-500 transition-all duration-500" style={{ width: `${progress}%` }} />
            </div>
            <div className="aspect-video rounded-xl shimmer" />
          </div>
        )}

        {output && (
          <div className="glass card-glow rounded-2xl overflow-hidden anim-pop">
            <img src={output} alt={tool.title} className="w-full object-cover" />
            <div className="p-3 text-xs text-[#8a8a93]">Generated by Nano Banana</div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="mb-5">
        <div className="text-[10px] tracking-[0.3em] text-pink-300/80 font-semibold mb-1">
          CREATIVE STUDIO
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Visual & Audio Tools</h1>
      </div>

      <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">VISUAL GENERATION</div>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {VISUAL_TOOLS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTool(t)}
            className="glass card-glow rounded-2xl p-4 text-left hover:bg-white/8 transition-all group"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-pink-500/20 to-purple-500/20 flex items-center justify-center text-lg mb-2.5 group-hover:scale-110 transition-transform">
              {t.icon}
            </div>
            <div className="text-[12.5px] font-semibold mb-0.5">{t.title}</div>
            <div className="text-[10px] text-[#8a8a93] leading-snug">{t.desc}</div>
          </button>
        ))}
      </div>

      <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">AUDIO GENERATION</div>
      <div className="glass card-glow rounded-2xl p-5 mb-3">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🎙️</span>
          <div>
            <h3 className="text-[14px] font-semibold">AI Voiceover</h3>
            <p className="text-[11px] text-[#8a8a93]">Turn any script into natural speech</p>
          </div>
        </div>
        <textarea
          value={voiceScript}
          onChange={(e) => setVoiceScript(e.target.value)}
          placeholder="Type your voiceover script here..."
          rows={3}
          className="w-full glass rounded-xl px-4 py-3 text-sm outline-none bg-white/5 border border-white/10 focus:border-pink-400/40 resize-none mb-3"
        />
        <div className="flex gap-2">
          <button
            onClick={speak}
            disabled={speaking || !voiceScript.trim()}
            className="grad-btn flex-1 rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50"
          >
            {speaking ? "🔊 Speaking..." : "▶ Generate Voiceover"}
          </button>
          {speaking && (
            <button onClick={stopSpeak} className="glass rounded-xl px-4 py-2.5 text-xs hover:bg-white/10">
              Stop
            </button>
          )}
        </div>
      </div>

      <div className="glass rounded-2xl p-4 text-xs text-[#8a8a93]">
        🎵 AI Music, Sound Effects, Animation, and Video Editor tools are in active development. Voiceovers and audiobooks are live now using natural device speech synthesis.
      </div>
    </div>
  );
}
