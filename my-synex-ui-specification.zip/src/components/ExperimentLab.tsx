import { useState } from "react";
import { useStore } from "../state/store";

interface Scenario {
  id: string;
  name: string;
  icon: string;
  inputs: { label: string; key: string; placeholder: string; type?: string }[];
}

const SCENARIOS: Scenario[] = [
  {
    id: "startup",
    name: "Startup Revenue",
    icon: "🚀",
    inputs: [
      { label: "Monthly Revenue", key: "revenue", placeholder: "10000", type: "number" },
      { label: "Growth Rate %", key: "growth", placeholder: "15", type: "number" },
      { label: "Months", key: "months", placeholder: "12", type: "number" },
    ],
  },
  {
    id: "study",
    name: "Study Schedule",
    icon: "📚",
    inputs: [
      { label: "Hours per Day", key: "hours", placeholder: "4", type: "number" },
      { label: "Total Topics", key: "topics", placeholder: "20", type: "number" },
      { label: "Days Available", key: "days", placeholder: "30", type: "number" },
    ],
  },
  {
    id: "budget",
    name: "Budget Planning",
    icon: "💰",
    inputs: [
      { label: "Monthly Income", key: "income", placeholder: "5000", type: "number" },
      { label: "Fixed Expenses", key: "fixed", placeholder: "3000", type: "number" },
      { label: "Savings Goal", key: "savings", placeholder: "1000", type: "number" },
    ],
  },
  {
    id: "fitness",
    name: "Fitness Plan",
    icon: "💪",
    inputs: [
      { label: "Current Weight (kg)", key: "current", placeholder: "80", type: "number" },
      { label: "Target Weight (kg)", key: "target", placeholder: "70", type: "number" },
      { label: "Weeks", key: "weeks", placeholder: "12", type: "number" },
    ],
  },
  {
    id: "investment",
    name: "Investment Growth",
    icon: "📈",
    inputs: [
      { label: "Initial Investment", key: "initial", placeholder: "10000", type: "number" },
      { label: "Monthly Contribution", key: "monthly", placeholder: "500", type: "number" },
      { label: "Annual Return %", key: "return", placeholder: "8", type: "number" },
      { label: "Years", key: "years", placeholder: "10", type: "number" },
    ],
  },
  {
    id: "mortgage",
    name: "Mortgage Calculator",
    icon: "🏠",
    inputs: [
      { label: "Home Price", key: "price", placeholder: "300000", type: "number" },
      { label: "Down Payment %", key: "down", placeholder: "20", type: "number" },
      { label: "Interest Rate %", key: "rate", placeholder: "4.5", type: "number" },
      { label: "Years", key: "years", placeholder: "30", type: "number" },
    ],
  },
  {
    id: "travel",
    name: "Trip Planner",
    icon: "✈️",
    inputs: [
      { label: "Destination", key: "destination", placeholder: "Paris, France", type: "text" },
      { label: "Days", key: "days", placeholder: "7", type: "number" },
      { label: "Budget", key: "budget", placeholder: "2000", type: "number" },
      { label: "Travelers", key: "travelers", placeholder: "2", type: "number" },
    ],
  },
  {
    id: "retirement",
    name: "Retirement Planner",
    icon: "🏖️",
    inputs: [
      { label: "Current Age", key: "age", placeholder: "30", type: "number" },
      { label: "Retirement Age", key: "retire", placeholder: "65", type: "number" },
      { label: "Current Savings", key: "savings", placeholder: "50000", type: "number" },
      { label: "Monthly Contribution", key: "contribution", placeholder: "1000", type: "number" },
    ],
  },
  {
    id: "business",
    name: "Business Break-Even",
    icon: "📊",
    inputs: [
      { label: "Fixed Costs", key: "fixed", placeholder: "5000", type: "number" },
      { label: "Variable Cost/Unit", key: "variable", placeholder: "10", type: "number" },
      { label: "Selling Price/Unit", key: "price", placeholder: "25", type: "number" },
      { label: "Target Units", key: "target", placeholder: "1000", type: "number" },
    ],
  },
  {
    id: "reading",
    name: "Reading Challenge",
    icon: "📖",
    inputs: [
      { label: "Books Goal", key: "books", placeholder: "52", type: "number" },
      { label: "Pages per Hour", key: "speed", placeholder: "30", type: "number" },
      { label: "Avg Book Pages", key: "pages", placeholder: "300", type: "number" },
      { label: "Days per Week", key: "days", placeholder: "5", type: "number" },
    ],
  },
  {
    id: "car",
    name: "Car Affordability",
    icon: "🚗",
    inputs: [
      { label: "Monthly Income", key: "income", placeholder: "5000", type: "number" },
      { label: "Current Car Value", key: "trade", placeholder: "5000", type: "number" },
      { label: "Down Payment", key: "down", placeholder: "3000", type: "number" },
      { label: "Max Monthly Payment", key: "payment", placeholder: "400", type: "number" },
    ],
  },
  {
    id: "time",
    name: "Time Value of Money",
    icon: "⏰",
    inputs: [
      { label: "Present Value", key: "pv", placeholder: "1000", type: "number" },
      { label: "Interest Rate %", key: "rate", placeholder: "5", type: "number" },
      { label: "Years", key: "years", placeholder: "10", type: "number" },
      { label: "Compounding (times/year)", key: "compound", placeholder: "12", type: "number" },
    ],
  },
];

export default function ExperimentLab() {
  const { sendMessage } = useStore();
  const [activeScenario, setActiveScenario] = useState<Scenario | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const calculate = async () => {
    if (!activeScenario) return;
    setLoading(true);

    let query = "";
    const v = values;
    
    switch (activeScenario.id) {
      case "startup": {
        const rev = parseFloat(v.revenue) || 10000;
        const growth = parseFloat(v.growth) || 15;
        const months = parseFloat(v.months) || 12;
        const projections = [];
        let current = rev;
        for (let i = 1; i <= months; i++) {
          current = current * (1 + growth / 100);
          projections.push(`Month ${i}: $${current.toFixed(0)}`);
        }
        query = `Analyze this startup projection. Starting at $${rev}/month with ${growth}% monthly growth over ${months} months. Projections: ${projections.join(", ")}. What are the key insights, risks, and recommendations?`;
        break;
      }
      case "study": {
        const hours = parseFloat(v.hours) || 4;
        const topics = parseFloat(v.topics) || 20;
        const days = parseFloat(v.days) || 30;
        const hoursPerTopic = (hours * days) / topics;
        query = `Create an optimized study schedule. I have ${days} days to study ${topics} topics, with ${hours} hours per day available. That's about ${hoursPerTopic.toFixed(1)} hours per topic. Give me a week-by-week breakdown with rest days and review sessions.`;
        break;
      }
      case "budget": {
        const income = parseFloat(v.income) || 5000;
        const fixed = parseFloat(v.fixed) || 3000;
        const savings = parseFloat(v.savings) || 1000;
        const flexible = income - fixed - savings;
        query = `Analyze this budget. Income $${income}, fixed expenses $${fixed}, savings goal $${savings}, leaving $${flexible} for flexible spending. Is this realistic? What adjustments would you recommend?`;
        break;
      }
      case "fitness": {
        const current = parseFloat(v.current) || 80;
        const target = parseFloat(v.target) || 70;
        const weeks = parseFloat(v.weeks) || 12;
        const weeklyLoss = (current - target) / weeks;
        query = `Create a fitness plan. Current weight ${current}kg, target ${target}kg, over ${weeks} weeks. That's about ${weeklyLoss.toFixed(2)}kg per week. Give me workout schedule, diet tips, and milestone tracking.`;
        break;
      }
      case "investment": {
        const initial = parseFloat(v.initial) || 10000;
        const monthly = parseFloat(v.monthly) || 500;
        const ret = parseFloat(v.return) || 8;
        const years = parseFloat(v.years) || 10;
        query = `Analyze this investment scenario. Starting with $${initial}, adding $${monthly}/month, with ${ret}% annual return over ${years} years. Calculate the final value and explain compound growth.`;
        break;
      }
      case "mortgage": {
        const price = parseFloat(v.price) || 300000;
        const down = parseFloat(v.down) || 20;
        const rate = parseFloat(v.rate) || 4.5;
        const years = parseFloat(v.years) || 30;
        const loan = price * (1 - down / 100);
        const monthlyRate = rate / 100 / 12;
        const numPayments = years * 12;
        const monthlyPayment = loan * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
        query = `Analyze this mortgage. Home price $${price}, ${down}% down ($${loan} loan), ${rate}% interest, ${years} years. Monthly payment is approximately $${monthlyPayment.toFixed(2)}. Discuss affordability and strategies to pay off faster.`;
        break;
      }
      case "travel": {
        query = `Plan a trip to ${v.destination || "Paris"} for ${v.days || 7} days with ${v.travelers || 2} travelers and a budget of $${v.budget || 2000}. Break down costs and suggest itinerary.`;
        break;
      }
      case "retirement": {
        const age = parseFloat(v.age) || 30;
        const retire = parseFloat(v.retire) || 65;
        const savings = parseFloat(v.savings) || 50000;
        const contribution = parseFloat(v.contribution) || 1000;
        const years = retire - age;
        query = `Retirement planning analysis. Currently ${age}, want to retire at ${retire} (${years} years). Have $${savings} saved, contributing $${contribution}/month. Project future savings and assess if this is sufficient.`;
        break;
      }
      case "business": {
        const fixed = parseFloat(v.fixed) || 5000;
        const variable = parseFloat(v.variable) || 10;
        const price = parseFloat(v.price) || 25;
        const target = parseFloat(v.target) || 1000;
        const breakEven = fixed / (price - variable);
        query = `Business break-even analysis. Fixed costs $${fixed}, variable cost $${variable}/unit, selling price $${price}/unit. Break-even is at ${breakEven.toFixed(0)} units. For ${target} units, analyze profit margins and recommendations.`;
        break;
      }
      case "reading": {
        const books = parseFloat(v.books) || 52;
        const speed = parseFloat(v.speed) || 30;
        const pages = parseFloat(v.pages) || 300;
        const days = parseFloat(v.days) || 5;
        const hoursPerBook = pages / speed;
        const totalHours = books * hoursPerBook;
        const hoursPerWeek = (totalHours / 365) * 7;
        query = `Reading challenge analysis. Goal: ${books} books, ${pages} pages each, reading at ${speed} pages/hour. That's ${hoursPerBook.toFixed(1)} hours per book, ${totalHours.toFixed(0)} total hours. Reading ${days} days/week means ${hoursPerWeek.toFixed(1)} hours per week. Is this realistic?`;
        break;
      }
      case "car": {
        const income = parseFloat(v.income) || 5000;
        const trade = parseFloat(v.trade) || 5000;
        const down = parseFloat(v.down) || 3000;
        const payment = parseFloat(v.payment) || 400;
        const maxCarPrice = (payment * 60) + down + trade;
        query = `Car affordability analysis. Monthly income $${income}, trade-in value $${trade}, down payment $${down}, max monthly payment $${payment}. Can afford approximately $${maxCarPrice} car. Discuss the 20/4/10 rule.`;
        break;
      }
      case "time": {
        const pv = parseFloat(v.pv) || 1000;
        const rate = parseFloat(v.rate) || 5;
        const years = parseFloat(v.years) || 10;
        const compound = parseFloat(v.compound) || 12;
        const fv = pv * Math.pow(1 + rate / 100 / compound, compound * years);
        query = `Time value of money calculation. Present value $${pv}, ${rate}% interest, ${years} years, compounded ${compound} times per year. Future value is $${fv.toFixed(2)}. Explain the power of compound interest.`;
        break;
      }
    }

    try {
      const res = await fetch(`https://text.pollinations.ai/${encodeURIComponent(query)}?system=${encodeURIComponent("You are an expert consultant. Give clear, actionable advice. Use simple formatting without special characters. Be encouraging but realistic.")}`);
      let text = await res.text();
      text = text.replace(/[:_\-*~`#]/g, '');
      setResult(text);
    } catch {
      setResult("Sorry, I couldn't process that scenario right now. Try again in a moment.");
    }
    setLoading(false);
  };

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-purple-300/80 font-semibold mb-1">
            EXPERIMENT LAB
          </div>
          <h1 className="text-2xl font-bold tracking-tight">What-If Scenarios</h1>
        </div>
      </div>

      {!activeScenario ? (
        <div className="grid grid-cols-2 gap-3 anim-fade">
          {SCENARIOS.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                setActiveScenario(s);
                setValues({});
                setResult(null);
              }}
              className="glass card-glow rounded-2xl p-5 text-left hover:bg-white/8 transition-all group"
            >
              <div className="text-3xl mb-3 group-hover:scale-110 transition-transform">{s.icon}</div>
              <div className="text-[15px] font-semibold mb-1">{s.name}</div>
              <div className="text-[11px] text-[#8a8a93]">Run projections</div>
            </button>
          ))}
        </div>
      ) : (
        <div className="anim-slide-up">
          <button
            onClick={() => setActiveScenario(null)}
            className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4"
          >
            ← Back to Scenarios
          </button>

          <div className="glass card-glow rounded-2xl p-5 mb-4">
            <div className="flex items-center gap-3 mb-5">
              <span className="text-3xl">{activeScenario.icon}</span>
              <div>
                <h2 className="text-lg font-bold">{activeScenario.name}</h2>
                <p className="text-[11px] text-[#8a8a93]">Enter your parameters</p>
              </div>
            </div>

            <div className="space-y-4">
              {activeScenario.inputs.map((input) => (
                <div key={input.key}>
                  <label className="text-[12px] text-[#8a8a93] mb-1.5 block">{input.label}</label>
                  <input
                    type={input.type || "text"}
                    value={values[input.key] || ""}
                    onChange={(e) => setValues({ ...values, [input.key]: e.target.value })}
                    placeholder={input.placeholder}
                    className="w-full glass rounded-xl px-4 py-3 text-sm outline-none bg-white/5 border border-white/10 focus:border-purple-400/40"
                  />
                </div>
              ))}
            </div>

            <button
              onClick={calculate}
              disabled={loading || activeScenario.inputs.some((i) => !values[i.key])}
              className="grad-btn w-full rounded-xl py-3.5 font-semibold text-sm mt-5 disabled:opacity-40 disabled:pointer-events-none"
            >
              {loading ? "Calculating..." : "Run Simulation"}
            </button>
          </div>

          {result && (
            <div className="glass rounded-2xl p-5 anim-slide-up">
              <div className="text-[10px] tracking-[0.25em] text-cyan-300/80 font-semibold mb-3">
                RESULTS
              </div>
              <p className="text-[14px] leading-relaxed text-white/85 whitespace-pre-line">
                {result}
              </p>
              <button
                onClick={() => sendMessage(`I ran a ${activeScenario.name} simulation. Can you give me more detailed advice based on these results?`)}
                className="glass rounded-xl px-4 py-2 text-xs text-cyan-300 hover:bg-white/10 mt-4 transition-colors"
              >
                Discuss with Synex →
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
