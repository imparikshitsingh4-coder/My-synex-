import { useState, useMemo } from "react";
import { useStore } from "../state/store";

const COUNTRIES: Record<string, { flag: string; cities: string[] }> = {
  "United States": { flag: "🇺🇸", cities: ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Jacksonville", "Fort Worth", "Columbus", "Charlotte", "San Francisco", "Indianapolis", "Seattle", "Denver", "Washington DC", "Boston", "Las Vegas", "Miami", "Atlanta", "Portland"] },
  "United Kingdom": { flag: "🇬🇧", cities: ["London", "Manchester", "Birmingham", "Leeds", "Glasgow", "Sheffield", "Bradford", "Liverpool", "Edinburgh", "Bristol", "Cardiff", "Belfast", "Leicester", "Coventry", "Nottingham", "Newcastle", "Brighton", "Plymouth", "Stoke", "Wolverhampton"] },
  "Japan": { flag: "🇯🇵", cities: ["Tokyo", "Yokohama", "Osaka", "Nagoya", "Sapporo", "Fukuoka", "Kobe", "Kawasaki", "Kyoto", "Saitama", "Hiroshima", "Sendai", "Kitakyushu", "Chiba", "Sakai", "Niigata", "Hamamatsu", "Okayama", "Sagamihara", "Kumamoto"] },
  "India": { flag: "🇮🇳", cities: ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Ahmedabad", "Chennai", "Kolkata", "Surat", "Pune", "Jaipur", "Lucknow", "Kanpur", "Nagpur", "Indore", "Thane", "Bhopal", "Visakhapatnam", "Patna", "Vadodara", "Ghaziabad", "Goa", "Chandigarh"] },
  "Germany": { flag: "🇩🇪", cities: ["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Dortmund", "Essen", "Leipzig", "Bremen", "Dresden", "Hanover", "Nuremberg", "Duisburg", "Bochum", "Wuppertal", "Bielefeld", "Bonn", "Münster"] },
  "France": { flag: "🇫🇷", cities: ["Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier", "Bordeaux", "Lille", "Rennes", "Reims", "Le Havre", "Saint-Étienne", "Toulon", "Grenoble", "Dijon", "Angers", "Nîmes", "Villeurbanne"] },
  "Brazil": { flag: "🇧🇷", cities: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador", "Fortaleza", "Belo Horizonte", "Manaus", "Curitiba", "Recife", "Goiânia", "Belém", "Porto Alegre", "Guarulhos", "Campinas", "São Luís", "São Gonçalo", "Maceió", "Duque de Caxias", "Natal", "Campo Grande"] },
  "China": { flag: "🇨🇳", cities: ["Shanghai", "Beijing", "Guangzhou", "Shenzhen", "Chengdu", "Nanjing", "Wuhan", "Xi'an", "Hangzhou", "Chongqing", "Tianjin", "Suzhou", "Harbin", "Jinan", "Zhengzhou", "Changsha", "Kunming", "Dalian", "Shenyang", "Qingdao", "Hong Kong", "Macau"] },
  "Australia": { flag: "🇦🇺", cities: ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Newcastle", "Canberra", "Sunshine Coast", "Wollongong", "Hobart", "Geelong", "Townsville", "Cairns", "Darwin", "Toowoomba", "Ballarat", "Bendigo", "Albury", "Launceston"] },
  "Canada": { flag: "🇨🇦", cities: ["Toronto", "Montreal", "Vancouver", "Calgary", "Edmonton", "Ottawa", "Winnipeg", "Quebec City", "Hamilton", "Kitchener", "London", "Victoria", "Halifax", "Oshawa", "Windsor", "Saskatoon", "St. Catharines", "Regina", "Barrie", "Guelph"] },
  "Italy": { flag: "🇮🇹", cities: ["Rome", "Milan", "Naples", "Turin", "Palermo", "Genoa", "Bologna", "Florence", "Bari", "Catania", "Venice", "Verona", "Messina", "Padua", "Trieste", "Taranto", "Brescia", "Prato", "Parma", "Modena"] },
  "Spain": { flag: "🇪🇸", cities: ["Madrid", "Barcelona", "Valencia", "Seville", "Zaragoza", "Málaga", "Murcia", "Palma", "Las Palmas", "Bilbao", "Alicante", "Córdoba", "Valladolid", "Vigo", "Gijón", "Hospitalet", "Vitoria", "La Coruña", "Granada", "Elche"] },
  "Russia": { flag: "🇷🇺", cities: ["Moscow", "Saint Petersburg", "Novosibirsk", "Yekaterinburg", "Nizhny Novgorod", "Kazan", "Chelyabinsk", "Omsk", "Samara", "Rostov", "Ufa", "Krasnoyarsk", "Perm", "Voronezh", "Volgograd", "Krasnodar", "Saratov", "Tyumen", "Tolyatti", "Izhevsk"] },
  "South Korea": { flag: "🇰🇷", cities: ["Seoul", "Busan", "Incheon", "Daegu", "Daejeon", "Gwangju", "Suwon", "Ulsan", "Changwon", "Goyang", "Yongin", "Bucheon", "Ansan", "Cheongju", "Jeonju", "Anyang", "Cheonan", "Namyangju", "Pohang", "Uijeongbu"] },
  "Mexico": { flag: "🇲🇽", cities: ["Mexico City", "Guadalajara", "Monterrey", "Puebla", "Tijuana", "León", "Juárez", "Zapopan", "Mérida", "San Luis Potosí", "Toluca", "Querétaro", "Mexicali", "Hermosillo", "Aguascalientes", "Cancún", "Chihuahua", "Morelia", "Saltillo", "Veracruz"] },
  "Turkey": { flag: "🇹🇷", cities: ["Istanbul", "Ankara", "Izmir", "Bursa", "Adana", "Gaziantep", "Konya", "Antalya", "Kayseri", "Mersin", "Eskişehir", "Diyarbakır", "Samsun", "Denizli", "Şanlıurfa", "Malatya", "Kahramanmaraş", "Erzurum", "Van", "Batman"] },
  "Indonesia": { flag: "🇮🇩", cities: ["Jakarta", "Surabaya", "Bandung", "Bekasi", "Medan", "Tangerang", "Depok", "Semarang", "Palembang", "Makassar", "South Tangerang", "Batam", "Pekanbaru", "Bogor", "Bandar Lampung", "Padang", "Malang", "Denpasar", "Samarinda", "Tasikmalaya"] },
  "Saudi Arabia": { flag: "🇸🇦", cities: ["Riyadh", "Jeddah", "Mecca", "Medina", "Dammam", "Tabuk", "Buraidah", "Khamis Mushait", "Hofuf", "Taif", "Najran", "Hail", "Jubail", "Yanbu", "Abha", "Arar", "Jizan", "Sakaka", "Qurayyat", "Dhahran"] },
  "Argentina": { flag: "🇦🇷", cities: ["Buenos Aires", "Córdoba", "Rosario", "Mendoza", "La Plata", "Tucumán", "Mar del Plata", "Salta", "Santa Fe", "San Juan", "Resistencia", "Santiago del Estero", "Corrientes", "Neuquén", "Posadas", "San Salvador de Jujuy", "Bahía Blanca", "Paraná", "Formosa", "San Luis"] },
  "Egypt": { flag: "🇪🇬", cities: ["Cairo", "Alexandria", "Giza", "Shubra El Kheima", "Port Said", "Suez", "Luxor", "Mansoura", "El Mahalla", "Tanta", "Asyut", "Ismailia", "Faiyum", "Zagazig", "Damietta", "Aswan", "Minya", "Damanhur", "Beni Suef", "Hurghada"] },
  "Nigeria": { flag: "🇳🇬", cities: ["Lagos", "Kano", "Ibadan", "Abuja", "Port Harcourt", "Benin City", "Maiduguri", "Zaria", "Aba", "Jos", "Ilorin", "Oyo", "Enugu", "Abeokuta", "Sokoto", "Onitsha", "Warri", "Calabar", "Kaduna", "Uyo"] },
  "Thailand": { flag: "🇹🇭", cities: ["Bangkok", "Nonthaburi", "Nakhon Ratchasima", "Chiang Mai", "Hat Yai", "Udon Thani", "Pak Kret", "Khon Kaen", "Nakhon Si Thammarat", "Lampang", "Si Racha", "Ayutthaya", "Chiang Rai", "Ubon Ratchathani", "Nakhon Sawan", "Chon Buri", "Rayong", "Yala", "Phuket", "Trang"] },
  "Vietnam": { flag: "🇻🇳", cities: ["Ho Chi Minh City", "Hanoi", "Da Nang", "Haiphong", "Biên Hòa", "Huế", "Nha Trang", "Cần Thơ", "Rạch Giá", "Qui Nhơn", "Vũng Tàu", "Nam Định", "Thái Nguyên", "Vinh", "Thủ Dầu Một", "Buôn Ma Thuột", "Đà Lạt", "Hạ Long", "Phan Thiết", "Vĩnh Yên"] },
  "South Africa": { flag: "🇿🇦", cities: ["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth", "Bloemfontein", "Nelspruit", "Kimberley", "Polokwane", "Pietermaritzburg", "Rustenburg", "East London", "Mbombela", "Vereeniging", "Welkom", "Newcastle", "George", "Klerksdorp", "Centurion", "Krugersdorp"] },
  "Pakistan": { flag: "🇵🇰", cities: ["Karachi", "Lahore", "Faisalabad", "Rawalpindi", "Gujranwala", "Multan", "Peshawar", "Sargodha", "Sialkot", "Quetta", "Bahawalpur", "Sukkur", "Jhang", "Sheikhupura", "Larkana", "Gujrat", "Mardan", "Kasur", "Rahim Yar Khan", "Sahiwal", "Islamabad"] },
  "Bangladesh": { flag: "🇧🇩", cities: ["Dhaka", "Chittagong", "Khulna", "Rajshahi", "Sylhet", "Barisal", "Rangpur", "Comilla", "Narayanganj", "Gazipur", "Mymensingh", "Jessore", "Cox's Bazar", "Bogra", "Dinajpur", "Tangail", "Jamalpur", "Pabna", "Naogaon", "Sirajganj"] },
  "Philippines": { flag: "🇵🇭", cities: ["Quezon City", "Manila", "Davao City", "Caloocan", "Cebu City", "Zamboanga City", "Antipolo", "Pasig", "Taguig", "Valenzuela", "Makati", "Marikina", "Muntinlupa", "Las Piñas", "Mandaluyong", "Bacolod", "Iloilo City", "Parañaque", "Cagayan de Oro", "General Santos"] },
  "Netherlands": { flag: "🇳🇱", cities: ["Amsterdam", "Rotterdam", "The Hague", "Utrecht", "Eindhoven", "Groningen", "Tilburg", "Almere", "Breda", "Nijmegen", "Enschede", "Haarlem", "Arnhem", "Zaanstad", "Amersfoort"] },
  "Sweden": { flag: "🇸🇪", cities: ["Stockholm", "Gothenburg", "Malmö", "Uppsala", "Västerås", "Örebro", "Linköping", "Helsingborg", "Jönköping", "Norrköping", "Lund", "Umeå", "Gävle", "Borås", "Södertälje"] },
  "Norway": { flag: "🇳🇴", cities: ["Oslo", "Bergen", "Trondheim", "Stavanger", "Drammen", "Fredrikstad", "Kristiansand", "Tromsø", "Sandnes", "Sarpsborg", "Skien", "Ålesund", "Sandefjord", "Haugesund", "Tønsberg"] },
  "Denmark": { flag: "🇩🇰", cities: ["Copenhagen", "Aarhus", "Odense", "Aalborg", "Esbjerg", "Randers", "Kolding", "Horsens", "Vejle", "Roskilde", "Herning", "Silkeborg", "Næstved", "Fredericia", "Viborg"] },
  "Finland": { flag: "🇫🇮", cities: ["Helsinki", "Espoo", "Tampere", "Vantaa", "Oulu", "Turku", "Jyväskylä", "Lahti", "Kuopio", "Pori", "Kouvola", "Joensuu", "Lappeenranta", "Hämeenlinna", "Vaasa"] },
  "Poland": { flag: "🇵🇱", cities: ["Warsaw", "Kraków", "Łódź", "Wrocław", "Poznań", "Gdańsk", "Szczecin", "Bydgoszcz", "Lublin", "Białystok", "Katowice", "Gdynia", "Częstochowa", "Radom", "Toruń"] },
  "Portugal": { flag: "🇵🇹", cities: ["Lisbon", "Porto", "Vila Nova de Gaia", "Amadora", "Braga", "Funchal", "Coimbra", "Setúbal", "Almada", "Agualva-Cacém", "Queluz", "Aveiro", "Faro", "Évora", "Guimarães"] },
  "Greece": { flag: "🇬🇷", cities: ["Athens", "Thessaloniki", "Patras", "Heraklion", "Larissa", "Volos", "Rhodes", "Ioannina", "Chania", "Chalcis", "Serres", "Alexandroupoli", "Xanthi", "Kavala", "Katerini"] },
  "Switzerland": { flag: "🇨🇭", cities: ["Zurich", "Geneva", "Basel", "Bern", "Lausanne", "Winterthur", "Lucerne", "St. Gallen", "Lugano", "Biel", "Thun", "Köniz", "Fribourg", "Schaffhausen", "Chur"] },
  "Austria": { flag: "🇦🇹", cities: ["Vienna", "Graz", "Linz", "Salzburg", "Innsbruck", "Klagenfurt", "Villach", "Wels", "Sankt Pölten", "Dornbirn", "Wiener Neustadt", "Steyr", "Feldkirch", "Bregenz", "Leonding"] },
  "Belgium": { flag: "🇧🇪", cities: ["Brussels", "Antwerp", "Ghent", "Charleroi", "Liège", "Bruges", "Namur", "Leuven", "Mons", "Aalst", "Mechelen", "La Louvière", "Kortrijk", "Hasselt", "Ostend"] },
  "Ireland": { flag: "🇮🇪", cities: ["Dublin", "Cork", "Limerick", "Galway", "Waterford", "Drogheda", "Swords", "Dundalk", "Bray", "Navan", "Kilkenny", "Ennis", "Carlow", "Tralee", "Naas"] },
  "New Zealand": { flag: "🇳🇿", cities: ["Auckland", "Wellington", "Christchurch", "Hamilton", "Tauranga", "Napier-Hastings", "Dunedin", "Palmerston North", "Nelson", "Rotorua", "New Plymouth", "Whangarei", "Invercargill", "Whanganui", "Gisborne"] },
  "Chile": { flag: "🇨🇱", cities: ["Santiago", "Valparaíso", "Concepción", "La Serena", "Antofagasta", "Temuco", "Rancagua", "Talca", "Arica", "Chillán", "Iquique", "Los Ángeles", "Puerto Montt", "Calama", "Copiapó"] },
  "Colombia": { flag: "🇨🇴", cities: ["Bogotá", "Medellín", "Cali", "Barranquilla", "Cartagena", "Cúcuta", "Bucaramanga", "Pereira", "Santa Marta", "Ibagué", "Manizales", "Villavicencio", "Neiva", "Armenia", "Popayán"] },
  "Peru": { flag: "🇵🇪", cities: ["Lima", "Arequipa", "Trujillo", "Chiclayo", "Piura", "Iquitos", "Cusco", "Chimbote", "Huancayo", "Tacna", "Ica", "Sullana", "Juliaca", "Pucallpa", "Cajamarca"] },
  "Venezuela": { flag: "🇻🇪", cities: ["Caracas", "Maracaibo", "Valencia", "Barquisimeto", "Maracay", "Ciudad Guayana", "San Cristóbal", "Maturín", "Barcelona", "Turmero", "Petare", "Cabimas", "Mérida", "Cumaná", "Los Teques"] },
  "Ecuador": { flag: "🇪🇨", cities: ["Guayaquil", "Quito", "Cuenca", "Santo Domingo", "Machala", "Durán", "Manta", "Portoviejo", "Loja", "Ambato", "Esmeraldas", "Quevedo", "Riobamba", "Milagro", "Ibarra"] },
  "Malaysia": { flag: "🇲🇾", cities: ["Kuala Lumpur", "George Town", "Ipoh", "Shah Alam", "Petaling Jaya", "Johor Bahru", "Malacca City", "Alor Setar", "Kota Kinabalu", "Kuching", "Kuantan", "Klang", "Seremban", "Sandakan", "Miri"] },
  "Singapore": { flag: "🇸🇬", cities: ["Singapore"] },
  "United Arab Emirates": { flag: "🇦🇪", cities: ["Dubai", "Abu Dhabi", "Sharjah", "Al Ain", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain"] },
  "Qatar": { flag: "🇶🇦", cities: ["Doha", "Al Rayyan", "Al Wakrah", "Al Khor", "Umm Salal", "Al Shamal"] },
  "Kuwait": { flag: "🇰🇼", cities: ["Kuwait City", "Al Ahmadi", "Hawalli", "As Salimiyah", "Sabah as Salim", "Al Farwaniyah"] },
  "Israel": { flag: "🇮🇱", cities: ["Jerusalem", "Tel Aviv", "Haifa", "Rishon LeZion", "Petah Tikva", "Ashdod", "Netanya", "Beersheba", "Bnei Brak", "Holon"] },
  "Iran": { flag: "🇮🇷", cities: ["Tehran", "Mashhad", "Isfahan", "Karaj", "Shiraz", "Tabriz", "Qom", "Ahvaz", "Kermanshah", "Urmia"] },
  "Iraq": { flag: "🇮🇶", cities: ["Baghdad", "Basra", "Mosul", "Erbil", "Najaf", "Karbala", "Kirkuk", "Nasiriyah", "Amarah", "Diwaniyah"] },
  "Morocco": { flag: "🇲🇦", cities: ["Casablanca", "Rabat", "Fes", "Marrakesh", "Tangier", "Agadir", "Meknes", "Oujda", "Kenitra", "Tetouan"] },
  "Algeria": { flag: "🇩🇿", cities: ["Algiers", "Oran", "Constantine", "Annaba", "Blida", "Batna", "Djelfa", "Sétif", "Sidi Bel Abbès", "Biskra"] },
  "Tunisia": { flag: "🇹🇳", cities: ["Tunis", "Sfax", "Sousse", "Kairouan", "Bizerte", "Gabès", "Ariana", "Gafsa", "Monastir", "Nabeul"] },
  "Kenya": { flag: "🇰🇪", cities: ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret", "Thika", "Malindi", "Kitale", "Garissa", "Kakamega"] },
  "Ethiopia": { flag: "🇪🇹", cities: ["Addis Ababa", "Dire Dawa", "Mekelle", "Gondar", "Adama", "Hawassa", "Bahir Dar", "Jimma", "Dessie", "Jijiga"] },
  "Ghana": { flag: "🇬🇭", cities: ["Accra", "Kumasi", "Tamale", "Sekondi-Takoradi", "Sunyani", "Cape Coast", "Obuasi", "Teshie", "Tema", "Madina"] },
  "Ukraine": { flag: "🇺🇦", cities: ["Kyiv", "Kharkiv", "Odesa", "Dnipro", "Donetsk", "Zaporizhzhia", "Lviv", "Kryvyi Rih", "Mykolaiv", "Mariupol"] },
  "Czech Republic": { flag: "🇨🇿", cities: ["Prague", "Brno", "Ostrava", "Plzeň", "Liberec", "Olomouc", "Ústí nad Labem", "České Budějovice", "Hradec Králové", "Pardubice"] },
  "Hungary": { flag: "🇭🇺", cities: ["Budapest", "Debrecen", "Szeged", "Miskolc", "Pécs", "Győr", "Nyíregyháza", "Kecskemét", "Székesfehérvár", "Szombathely"] },
  "Romania": { flag: "🇷🇴", cities: ["Bucharest", "Cluj-Napoca", "Timișoara", "Iași", "Constanța", "Craiova", "Brașov", "Galați", "Ploiești", "Oradea"] },
  "Bulgaria": { flag: "🇧🇬", cities: ["Sofia", "Plovdiv", "Varna", "Burgas", "Ruse", "Stara Zagora", "Pleven", "Sliven", "Dobrich", "Shumen"] },
  "Serbia": { flag: "🇷🇸", cities: ["Belgrade", "Novi Sad", "Niš", "Kragujevac", "Subotica", "Zrenjanin", "Pančevo", "Čačak", "Novi Pazar", "Kraljevo"] },
  "Croatia": { flag: "🇭🇷", cities: ["Zagreb", "Split", "Rijeka", "Osijek", "Zadar", "Slavonski Brod", "Pula", "Karlovac", "Sisak", "Dubrovnik"] },
  "Sri Lanka": { flag: "🇱🇰", cities: ["Colombo", "Kandy", "Galle", "Jaffna", "Negombo", "Batticaloa", "Trincomalee", "Anuradhapura", "Ratnapura", "Matara"] },
  "Nepal": { flag: "🇳🇵", cities: ["Kathmandu", "Pokhara", "Lalitpur", "Bharatpur", "Biratnagar", "Birgunj", "Dharan", "Butwal", "Hetauda", "Janakpur"] },
  "Myanmar": { flag: "🇲🇲", cities: ["Yangon", "Mandalay", "Naypyidaw", "Mawlamyine", "Bago", "Pathein", "Monywa", "Meiktila", "Myitkyina", "Taunggyi"] },
  "Cambodia": { flag: "🇰🇭", cities: ["Phnom Penh", "Siem Reap", "Battambang", "Sihanoukville", "Poipet", "Kampong Cham", "Kampot", "Ta Khmau", "Pursat", "Kratié"] },
  "Mongolia": { flag: "🇲🇳", cities: ["Ulaanbaatar", "Erdenet", "Darkhan", "Choibalsan", "Mörön", "Nalaikh", "Khovd", "Ölgii", "Baganuur", "Sükhbaatar"] },
  "Kazakhstan": { flag: "🇰🇿", cities: ["Almaty", "Astana", "Shymkent", "Karaganda", "Aktobe", "Taraz", "Pavlodar", "Semey", "Atyrau", "Kostanay"] },
  "Taiwan": { flag: "🇹🇼", cities: ["Taipei", "Kaohsiung", "Taichung", "Tainan", "Banqiao", "Hsinchu", "Keelung", "Chiayi", "Changhua", "Pingtung"] },
  "Cuba": { flag: "🇨🇺", cities: ["Havana", "Santiago de Cuba", "Camagüey", "Holguín", "Santa Clara", "Guantánamo", "Bayamo", "Cienfuegos", "Matanzas", "Pinar del Río"] },
  "Jamaica": { flag: "🇯🇲", cities: ["Kingston", "Spanish Town", "Portmore", "Montego Bay", "May Pen", "Mandeville", "Old Harbour", "Savanna-la-Mar", "Linstead", "Ocho Rios"] },
  "Iceland": { flag: "🇮🇸", cities: ["Reykjavík", "Kópavogur", "Hafnarfjörður", "Akureyri", "Reykjanesbær", "Garðabær", "Mosfellsbær", "Árborg", "Akranes", "Fjarðabyggð"] },
};

export default function LiveWorldScreen() {
  const { sendMessage } = useStore();
  const [search, setSearch] = useState("");
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [info, setInfo] = useState<{ country: string; city: string; mapUrl: string; description: string } | null>(null);

  const filteredCountries = useMemo(() => {
    if (!search.trim()) return Object.keys(COUNTRIES);
    const q = search.toLowerCase();
    return Object.keys(COUNTRIES).filter(
      (c) => c.toLowerCase().includes(q) || COUNTRIES[c].cities.some((city) => city.toLowerCase().includes(q))
    );
  }, [search]);

  const handleCitySelect = async (country: string, city: string) => {
    setLoading(true);
    setSelectedCountry(null);

    const mapUrl = `https://image.pollinations.ai/prompt/aerial%20satellite%20map%20view%20of%20${encodeURIComponent(city)}%20${encodeURIComponent(country)}%20city%20high%20resolution%20cartography?nologo=1&seed=${Math.floor(Math.random() * 10000)}&width=800&height=450`;

    const query = `Tell me about ${city}, ${country}. Include key facts about its history, culture, economy, population, famous landmarks, and what makes it special. Keep it conversational and engaging.`;

    try {
      const res = await fetch(`https://text.pollinations.ai/${encodeURIComponent(query)}?system=${encodeURIComponent("You are a knowledgeable travel guide. Be enthusiastic and conversational. Avoid using colons, asterisks, or dashes. Just use natural sentences.")}`);
      let description = await res.text();
      description = description.replace(/[:_\-*~`#]/g, '');

      setInfo({ country, city, mapUrl, description });
    } catch {
      setInfo({
        country,
        city,
        mapUrl,
        description: `${city} is a wonderful city in ${country}. It has rich history and culture. I'd love to tell you more when my connection is better.`
      });
    }

    setLoading(false);
  };

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-emerald-300/80 font-semibold mb-1">
            LIVE WORLD
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Explore Earth</h1>
        </div>
        <span className="text-[10px] rounded-full bg-emerald-400/10 border border-emerald-400/30 text-emerald-300 px-2.5 py-1">
          {Object.keys(COUNTRIES).length} countries
        </span>
      </div>

      {!info && !loading && (
        <div className="glass-strong rounded-2xl px-4 py-3 flex items-center gap-2 mb-4">
          <span className="text-[#8a8a93]">🔍</span>
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setSelectedCountry(null); }}
            placeholder="Search countries or cities..."
            className="flex-1 bg-transparent outline-none text-sm placeholder:text-[#8a8a93]/70"
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-[#8a8a93] hover:text-white text-xs">✕</button>
          )}
        </div>
      )}

      {info ? (
        <div className="anim-slide-up">
          <button
            onClick={() => setInfo(null)}
            className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4"
          >
            ← Back to Map
          </button>

          <div className="glass card-glow rounded-3xl overflow-hidden mb-4">
            <div className="relative aspect-video">
              <img
                src={info.mapUrl}
                alt={`${info.city} map`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <h2 className="text-2xl font-bold">{info.city}</h2>
                <p className="text-emerald-300 font-semibold">{info.country}</p>
              </div>
            </div>
            <div className="p-5">
              <p className="text-[14px] leading-relaxed text-white/85 whitespace-pre-line">
                {info.description}
              </p>
              <button
                onClick={() => {
                  sendMessage(`Tell me more about ${info.city}, ${info.country}. What are the best places to visit?`);
                }}
                className="grad-btn w-full rounded-xl py-3 font-semibold text-sm mt-4"
              >
                Ask Synex More About {info.city}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {loading ? (
            <div className="glass rounded-2xl p-8 text-center anim-fade">
              <div className="text-3xl mb-3 animate-pulse">🌍</div>
              <p className="text-sm text-[#8a8a93]">Gathering location data...</p>
            </div>
          ) : (
            <>
              {!selectedCountry ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 anim-fade">
                  {filteredCountries.map((country) => (
                    <button
                      key={country}
                      onClick={() => setSelectedCountry(country)}
                      className="glass card-glow rounded-2xl p-4 text-left hover:bg-white/8 transition-all group"
                    >
                      <div className="text-2xl mb-2 group-hover:scale-110 transition-transform">
                        {COUNTRIES[country].flag}
                      </div>
                      <div className="text-[13px] font-semibold">{country}</div>
                      <div className="text-[10px] text-[#8a8a93]">{COUNTRIES[country].cities.length} cities</div>
                    </button>
                  ))}
                  {filteredCountries.length === 0 && (
                    <div className="col-span-full text-center py-10 text-sm text-[#8a8a93]">
                      No matches. Try a different search.
                    </div>
                  )}
                </div>
              ) : (
                <div className="anim-slide-up">
                  <button
                    onClick={() => setSelectedCountry(null)}
                    className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4"
                  >
                    ← Back to Countries
                  </button>
                  <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <span>{COUNTRIES[selectedCountry].flag}</span> {selectedCountry}
                  </h2>
                  <div className="grid grid-cols-2 gap-2">
                    {COUNTRIES[selectedCountry].cities.map((city) => (
                      <button
                        key={city}
                        onClick={() => handleCitySelect(selectedCountry, city)}
                        className="glass rounded-xl px-4 py-3 text-left text-[13px] hover:bg-white/10 hover:text-cyan-200 transition-all"
                      >
                        {city}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}
