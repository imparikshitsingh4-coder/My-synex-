export default function Logo({
  size = 40,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      aria-label="My Synex logo"
    >
      <defs>
        <linearGradient id="synexGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#c084fc" />
          <stop offset="55%" stopColor="#818cf8" />
          <stop offset="100%" stopColor="#22d3ee" />
        </linearGradient>
        <mask id="synexMask">
          <rect x="0" y="0" width="100" height="100" fill="#fff" />
          {/* diagonal slash cut */}
          <line
            x1="100"
            y1="14"
            x2="16"
            y2="72"
            stroke="#000"
            strokeWidth="6.5"
          />
          {/* angry left eye */}
          <polygon points="22,60 46,68 47,74 24,66" fill="#000" />
          {/* star right eye */}
          <polygon
            points="64,58 66.9,64.9 74.6,65.3 68.7,70.2 70.6,77.6 64,73.5 57.4,77.6 59.3,70.2 53.4,65.3 61.1,64.9"
            fill="#000"
          />
        </mask>
      </defs>
      {/* angular cat head: two ears with center notch, tapered chin */}
      <polygon
        points="10,4 40,34 50,28 60,34 90,4 83,60 50,96 17,60"
        fill="url(#synexGrad)"
        mask="url(#synexMask)"
      />
    </svg>
  );
}
