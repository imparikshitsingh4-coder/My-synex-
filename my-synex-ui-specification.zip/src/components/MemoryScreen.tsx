import { useState } from "react";
import { MODELS, useStore } from "../state/store";
import { IconBrain, IconLock } from "./icons";
import Constellation from "./Constellation";

const KIND_STYLE: Record<string, string> = {
  chat: "bg-purple-400",
  model: "bg-cyan-400",
  artifact: "bg-pink-400",
  system: "bg-emerald-400",
  personality: "bg-amber-400",
};

export default function MemoryScreen() {
  const {
    model,
    personality,
    turns,
    contextChips,
    timeline,
    messages,
    usage,
    totals,
    streak,
    tier,
    clearMemory,
    setTab,
    user,
  } = useStore();
  const [sub, setSub] = useState<"context" | "sessions" | "dev">("context");
  const modelName = MODELS.find((m) => m.id === model)!.name;

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="text-[10px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-1">
            MEMORY ENGINE
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Memory HUD</h1>
        </div>
        <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3.5 py-1.5 text-xs font-semibold text-emerald-300 shadow-[0_0_16px_rgba(52,211,153,0.2)]">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 pulse-dot" />
          Active
        </span>
      </div>

      {/* Sub tabs */}
      <div className="glass rounded-2xl p-1 grid grid-cols-3 gap-1 mb-5">
        {(
          [
            ["context", "Context"],
            ["sessions", "Sessions"],
            ["dev", "Dev Tools"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setSub(id)}
            className={`rounded-xl py-2 text-[13px] font-semibold transition-all duration-300 ${
              sub === id
                ? "bg-gradient-to-r from-cyan-500/25 to-purple-500/25 text-cyan-200"
                : "text-[#8a8a93] hover:text-white"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {sub === "context" && (
        <div className="space-y-4 anim-fade">
          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <div className="glass rounded-2xl p-3.5">
              <div className="text-[9px] tracking-[0.2em] text-[#8a8a93] mb-1.5">
                ACTIVE MODEL
              </div>
              <div className="text-[13px] font-bold text-purple-200 leading-tight">
                {modelName}
              </div>
            </div>
            <div className="glass rounded-2xl p-3.5">
              <div className="text-[9px] tracking-[0.2em] text-[#8a8a93] mb-1.5">
                PERSONALITY
              </div>
              <div className="text-[13px] font-bold text-cyan-200">{personality}</div>
            </div>
            <div className="glass rounded-2xl p-3.5">
              <div className="text-[9px] tracking-[0.2em] text-[#8a8a93] mb-1.5">
                TURNS TRACKED
              </div>
              <div className="text-xl font-bold glow-cyan-text">{turns}</div>
            </div>
          </div>

          {/* Context chips */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <IconBrain size={16} className="text-purple-300" />
              <span className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold">
                CONTEXT CHIPS
              </span>
            </div>
            {contextChips.length === 0 ? (
              <p className="text-sm text-[#8a8a93] py-4 text-center">
                No context established yet. Start a conversation in{" "}
                <button
                  onClick={() => setTab("workspace")}
                  className="text-cyan-300 hover:underline"
                >
                  Workspace
                </button>
                .
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {contextChips.map((c) => (
                  <span
                    key={c}
                    className="anim-pop rounded-full border border-cyan-400/25 bg-cyan-400/8 px-3 py-1 text-xs text-cyan-200 font-mono"
                  >
                    #{c}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Timeline */}
          <div className="glass rounded-2xl p-4">
            <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-4">
              MEMORY TIMELINE
            </div>
            {timeline.length === 0 ? (
              <p className="text-sm text-[#8a8a93] py-2 text-center">
                Timeline empty — events appear as you work.
              </p>
            ) : (
              <div className="relative pl-4 space-y-4 before:absolute before:left-[3px] before:top-1 before:bottom-1 before:w-px before:bg-white/10">
                {timeline.slice(0, 12).map((e) => (
                  <div key={e.id} className="relative anim-fade">
                    <span
                      className={`absolute -left-[16.5px] top-1 w-2 h-2 rounded-full ${KIND_STYLE[e.kind]} shadow-[0_0_8px_currentColor]`}
                    />
                    <div className="text-[13px] text-white/85 leading-snug">
                      {e.text}
                    </div>
                    <div className="text-[10px] text-[#8a8a93] font-mono mt-0.5">
                      {new Date(e.ts).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {sub === "sessions" && (
        <div className="space-y-4 anim-fade">
          {tier === "guest" ? (
            <div className="glass rounded-2xl py-12 px-6 text-center">
              <IconLock size={28} className="text-[#8a8a93] mx-auto mb-3" />
              <p className="text-sm text-white/85 font-semibold mb-1">
                Saved sessions require an account
              </p>
              <p className="text-xs text-[#8a8a93] mb-4">
                Guest Mode has no saved chats or long-term memory.
              </p>
              <button
                onClick={() => setTab("profile")}
                className="grad-btn rounded-full px-5 py-2 text-sm font-semibold"
              >
                Create free account
              </button>
            </div>
          ) : (
            <>
              <div className="glass rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[13px] font-semibold">
                    Current session · {user?.name ?? "Operator"}
                  </span>
                  <span className="text-[10px] rounded-full bg-emerald-400/10 border border-emerald-400/30 text-emerald-300 px-2.5 py-1">
                    ☁️ Cloud synced
                  </span>
                </div>
                <p className="text-xs text-[#8a8a93]">
                  {messages.length} messages · {turns} turns · persisted locally +
                  synced
                </p>
              </div>
              {messages.length > 0 && (
                <div className="glass rounded-2xl p-4 space-y-2.5 max-h-72 overflow-y-auto">
                  {messages.slice(-8).map((m) => (
                    <div key={m.id} className="text-xs leading-relaxed">
                      <span
                        className={
                          m.role === "user" ? "text-purple-300" : "text-cyan-300"
                        }
                      >
                        {m.role === "user" ? "you" : "synex"} ›{" "}
                      </span>
                      <span className="text-white/75">
                        {m.text.slice(0, 90)}
                        {m.text.length > 90 ? "…" : ""}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {sub === "dev" && (
        <div className="space-y-4 anim-fade">
          <Constellation />
          <div className="glass rounded-2xl p-4 font-mono text-[11px] leading-relaxed text-white/80 overflow-x-auto">
            <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-sans font-semibold mb-3">
              SYSTEM STATE
            </div>
            <pre className="whitespace-pre-wrap">{JSON.stringify(
              {
                engine: modelName,
                personality,
                tier,
                turns,
                context_chips: contextChips.length,
                usage_today: usage,
                lifetime: totals,
                streak_days: streak.count,
                memory: "active",
                canvas: "ready",
              },
              null,
              2
            )}</pre>
          </div>
          <button
            onClick={clearMemory}
            className="w-full glass rounded-2xl py-3 text-sm text-red-300 hover:bg-red-500/10 transition-colors"
          >
            ⚠ Purge Memory Engine (clears chat + context)
          </button>
        </div>
      )}
    </div>
  );
}
