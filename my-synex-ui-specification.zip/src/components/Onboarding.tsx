import { useState } from "react";
import { useStore } from "../state/store";
import Logo from "./Logo";
import { IconTerminal, IconBolt, IconSparkles, IconInfoNode } from "./icons";

const STEPS = [
  {
    pill: "SYSTEM BOOTING",
    icon: IconTerminal,
    title: "Welcome to My Synex",
    sub: "A cyber-grade AI workspace. Dual-pane chat + Canvas, personality-driven models, and real-time memory HUD.",
  },
  {
    pill: "MULTI-ENGINE",
    icon: IconBolt,
    title: "Switch Models on the Fly",
    sub: "Claude Sonnet 4.5, GPT-5.2, and Gemini 3 Pro — swap engines mid-conversation from the workspace header.",
  },
  {
    pill: "CREATOR SUITE",
    icon: IconSparkles,
    title: "Generate Images & Video",
    sub: "Prompt Nano Banana for images and Sora 2 for video posters — all rendered inline into your Canvas.",
  },
  {
    pill: "CONTEXT LOADED",
    icon: IconInfoNode,
    title: "Memory Engine Active",
    sub: "Track what the AI remembers in real time. Focus Mode hides distractions when it's time to build.",
  },
];

export default function Onboarding() {
  const { completeOnboarding } = useStore();
  const [step, setStep] = useState(0);
  const last = step === STEPS.length - 1;
  const S = STEPS[step];
  const Icon = S.icon;

  const next = () => (last ? completeOnboarding() : setStep(step + 1));

  return (
    <div className="bg-scene min-h-screen flex flex-col items-center justify-center px-5">
      <div className="flex items-center gap-2.5 mb-8 anim-fade">
        <Logo size={34} className="drop-shadow-[0_0_14px_rgba(139,92,246,0.7)]" />
        <span className="text-sm font-semibold tracking-[0.3em] text-white/80">
          MY SYNEX
        </span>
      </div>

      <div
        key={step}
        className="glass card-glow rounded-3xl w-full max-w-md px-8 py-12 text-center anim-slide-up"
      >
        {/* pill */}
        <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-1.5 mb-10">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-300 pulse-dot shadow-[0_0_10px_rgba(34,211,238,0.9)]" />
          <span className="text-[11px] font-semibold tracking-[0.22em] glow-cyan-text">
            {S.pill}
          </span>
        </div>

        {/* icon */}
        <div className="grad-icon mx-auto w-24 h-24 rounded-3xl flex items-center justify-center mb-9 floaty">
          <Icon size={44} className="text-white" strokeWidth={2} />
        </div>

        <h1 className="text-[26px] font-bold tracking-tight mb-3.5">{S.title}</h1>
        <p className="text-[#8a8a93] text-[15px] leading-relaxed max-w-xs mx-auto">
          {S.sub}
        </p>
      </div>

      {/* controls */}
      <div className="w-full max-w-md flex items-center justify-between mt-8 px-2">
        <button
          onClick={completeOnboarding}
          className="text-[#8a8a93] text-sm hover:text-white transition-colors px-2 py-2"
        >
          Skip
        </button>

        <div className="flex items-center gap-2">
          {STEPS.map((_, i) => (
            <button
              key={i}
              onClick={() => setStep(i)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === step
                  ? "w-6 bg-gradient-to-r from-purple-400 to-blue-400 shadow-[0_0_10px_rgba(139,92,246,0.8)]"
                  : "w-1.5 bg-white/25 hover:bg-white/50"
              }`}
              aria-label={`Step ${i + 1}`}
            />
          ))}
        </div>

        <button
          onClick={next}
          className="grad-btn rounded-full px-6 py-2.5 text-sm font-semibold text-white"
        >
          {last ? "Initialize Focus" : "Continue →"}
        </button>
      </div>
    </div>
  );
}
