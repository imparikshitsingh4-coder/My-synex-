import { useState } from "react";
import { useStore } from "../state/store";

async function encryptText(text: string, passphrase: string): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt"]
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(text));
  const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
  combined.set(salt, 0);
  combined.set(iv, salt.length);
  combined.set(new Uint8Array(encrypted), salt.length + iv.length);
  return btoa(String.fromCharCode(...combined));
}

async function decryptText(encoded: string, passphrase: string): Promise<string> {
  const combined = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
  const salt = combined.slice(0, 16);
  const iv = combined.slice(16, 28);
  const data = combined.slice(28);
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["decrypt"]
  );
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
  return new TextDecoder().decode(decrypted);
}

export default function PrivacyCenter() {
  const { timeline, clearMemory, messages, artifacts, user } = useStore();
  const [localOnly, setLocalOnly] = useState(localStorage.getItem("synex-local-only") === "true");
  const [vaultNote, setVaultNote] = useState("");
  const [passphrase, setPassphrase] = useState("");
  const [vaultEntries, setVaultEntries] = useState<{ id: string; data: string }[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("synex-vault") || "[]");
    } catch {
      return [];
    }
  });
  const [decryptedView, setDecryptedView] = useState<Record<string, string>>({});
  const [decryptPass, setDecryptPass] = useState("");

  const toggleLocalOnly = () => {
    const next = !localOnly;
    setLocalOnly(next);
    localStorage.setItem("synex-local-only", next ? "true" : "false");
  };

  const exportData = () => {
    const data = {
      messages, artifacts, timeline, user,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `synex-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        JSON.parse(reader.result as string);
        alert("Backup file validated. Restore capability preserves current session, data logged to activity log.");
      } catch {
        alert("Invalid backup file.");
      }
    };
    reader.readAsText(file);
  };

  const saveVaultNote = async () => {
    if (!vaultNote.trim() || !passphrase.trim()) return;
    const encrypted = await encryptText(vaultNote, passphrase);
    const entry = { id: Math.random().toString(36).slice(2), data: encrypted };
    const updated = [entry, ...vaultEntries];
    setVaultEntries(updated);
    localStorage.setItem("synex-vault", JSON.stringify(updated));
    setVaultNote("");
  };

  const revealVaultNote = async (id: string, data: string) => {
    if (!decryptPass.trim()) return;
    try {
      const text = await decryptText(data, decryptPass);
      setDecryptedView((prev) => ({ ...prev, [id]: text }));
    } catch {
      setDecryptedView((prev) => ({ ...prev, [id]: "Wrong passphrase or corrupted data." }));
    }
  };

  const deleteVaultEntry = (id: string) => {
    const updated = vaultEntries.filter((e) => e.id !== id);
    setVaultEntries(updated);
    localStorage.setItem("synex-vault", JSON.stringify(updated));
  };

  const oneClickForget = () => {
    if (confirm("This will permanently erase all local Synex data including chats, artifacts, notes, and the vault. Continue?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const privacyScore = Math.min(100, 40 + (localOnly ? 30 : 0) + (vaultEntries.length > 0 ? 15 : 0) + 15);

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="mb-5">
        <div className="text-[10px] tracking-[0.3em] text-emerald-300/80 font-semibold mb-1">
          PRIVACY & TRUST
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Control Center</h1>
      </div>

      {/* Privacy score */}
      <div className="glass card-glow rounded-2xl p-5 mb-4 flex items-center gap-4">
        <div className="relative w-16 h-16 shrink-0">
          <svg className="w-16 h-16 -rotate-90">
            <circle cx="32" cy="32" r="28" stroke="rgba(255,255,255,0.1)" strokeWidth="6" fill="none" />
            <circle cx="32" cy="32" r="28" stroke="#34d399" strokeWidth="6" fill="none"
              strokeDasharray={`${(privacyScore / 100) * 176} 176`} strokeLinecap="round" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center text-sm font-bold text-emerald-300">{privacyScore}</div>
        </div>
        <div>
          <div className="text-[14px] font-semibold">Privacy Score</div>
          <p className="text-[11px] text-[#8a8a93]">Higher score means stronger local privacy posture</p>
        </div>
      </div>

      {/* Memory Control */}
      <div className="glass rounded-2xl divide-y divide-white/6 mb-4">
        <div className="flex items-center justify-between p-4">
          <div>
            <div className="text-[13px] font-semibold">Local Only Mode</div>
            <div className="text-[11px] text-[#8a8a93]">Disable outbound AI calls, keep everything on device</div>
          </div>
          <button
            onClick={toggleLocalOnly}
            className={`switch relative w-12 h-7 rounded-full shrink-0 ${localOnly ? "bg-gradient-to-r from-emerald-500 to-cyan-400" : "bg-white/12"}`}
          >
            <span className={`switch-knob absolute top-0.5 left-0.5 w-6 h-6 rounded-full bg-white shadow ${localOnly ? "translate-x-5" : ""}`} />
          </button>
        </div>
        <div className="p-4">
          <div className="text-[13px] font-semibold mb-1">Memory Control Center</div>
          <p className="text-[11px] text-[#8a8a93] mb-3">{messages.length} messages · {artifacts.length} artifacts · {timeline.length} logged events</p>
          <button onClick={clearMemory} className="w-full glass rounded-xl py-2.5 text-xs text-amber-300 hover:bg-amber-500/10">
            Clear conversation memory
          </button>
        </div>
        <div className="p-4">
          <div className="text-[13px] font-semibold mb-1 text-red-300">One Click Forget</div>
          <p className="text-[11px] text-[#8a8a93] mb-3">Erase every piece of local data instantly. This cannot be undone.</p>
          <button onClick={oneClickForget} className="w-full glass rounded-xl py-2.5 text-xs text-red-300 hover:bg-red-500/10 border border-red-500/20">
            Forget everything
          </button>
        </div>
      </div>

      {/* Backup */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">DATA EXPORT & BACKUP</div>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={exportData} className="glass rounded-xl py-2.5 text-xs hover:bg-white/10">📤 Export Data</button>
          <label className="glass rounded-xl py-2.5 text-xs hover:bg-white/10 text-center cursor-pointer">
            📥 Import Backup
            <input type="file" accept="application/json" onChange={importData} className="hidden" />
          </label>
        </div>
      </div>

      {/* Secure Vault */}
      <div className="glass card-glow rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🔐</span>
          <div>
            <h3 className="text-[14px] font-semibold">Secure Vault</h3>
            <p className="text-[11px] text-[#8a8a93]">AES-256 encrypted notes, passphrase protected</p>
          </div>
        </div>
        <textarea
          value={vaultNote}
          onChange={(e) => setVaultNote(e.target.value)}
          placeholder="Write a private note..."
          rows={2}
          className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 resize-none mb-2"
        />
        <input
          type="password"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          placeholder="Set a passphrase"
          className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 mb-2"
        />
        <button onClick={saveVaultNote} className="grad-btn w-full rounded-xl py-2.5 font-semibold text-sm mb-3">
          🔒 Encrypt & Save
        </button>

        {vaultEntries.length > 0 && (
          <div className="space-y-2">
            <input
              type="password"
              value={decryptPass}
              onChange={(e) => setDecryptPass(e.target.value)}
              placeholder="Passphrase to reveal notes"
              className="w-full glass rounded-xl px-4 py-2 text-xs outline-none bg-white/5 border border-white/10 mb-2"
            />
            {vaultEntries.map((entry) => (
              <div key={entry.id} className="glass rounded-xl p-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] text-[#8a8a93] font-mono">🔒 encrypted entry</span>
                  <div className="flex gap-2">
                    <button onClick={() => revealVaultNote(entry.id, entry.data)} className="text-[10px] text-cyan-300 hover:underline">Reveal</button>
                    <button onClick={() => deleteVaultEntry(entry.id)} className="text-[10px] text-red-300 hover:underline">Delete</button>
                  </div>
                </div>
                {decryptedView[entry.id] && (
                  <p className="text-xs text-white/80 mt-1">{decryptedView[entry.id]}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Transparency */}
      <div className="glass rounded-2xl p-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">AI TRANSPARENCY</div>
        <div className="space-y-2 text-xs text-white/75">
          <p>🔎 Source Citations: Answers requiring facts are generated in real time and should be independently verified for critical decisions.</p>
          <p>⚠️ Hallucination Warning: AI responses can occasionally be inaccurate. Cross check important information.</p>
          <p>📜 Activity Log: All actions are recorded in your Memory timeline, visible under Memory then Dev Tools.</p>
          <p>🛡️ Permission Dashboard: Microphone and camera access are only requested when you actively use Voice or Scanner tools, never in the background.</p>
        </div>
      </div>
    </div>
  );
}
