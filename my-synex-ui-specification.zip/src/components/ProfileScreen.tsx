import { useState, useEffect } from "react";
import { MODELS, useStore, type Personality, type AnswerMode } from "../state/store";
import Logo from "./Logo";
import { IconCheck, IconChevronRight, IconFlame, IconTrophy, IconX, IconMic } from "./icons";

const PERSONALITIES: Personality[] = ["Balanced", "Technical", "Creative", "Concise"];
const MODES: AnswerMode[] = ["Short", "Detailed", "Expert", "Beginner", "Child"];

function SignUpModal({ onClose }: { onClose: () => void }) {
  const { signUp } = useStore();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const submit = () => {
    if (!name.trim() || !email.includes("@")) return;
    signUp(name.trim(), email.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm anim-fade" />
      <div
        className="relative glass-strong card-glow rounded-3xl w-full max-w-sm p-6 anim-pop"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <Logo size={26} />
            <span className="font-bold">Create Operator ID</span>
          </div>
          <button onClick={onClose} className="text-[#8a8a93] hover:text-white p-1">
            <IconX size={18} />
          </button>
        </div>
        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Callsign (name)"
            className="w-full glass rounded-xl px-4 py-3 text-sm outline-none placeholder:text-[#8a8a93]/70 focus:border-purple-400/40"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            type="email"
            className="w-full glass rounded-xl px-4 py-3 text-sm outline-none placeholder:text-[#8a8a93]/70 focus:border-purple-400/40"
          />
          <button
            onClick={submit}
            disabled={!name.trim() || !email.includes("@")}
            className="grad-btn w-full rounded-xl py-3 text-sm font-semibold disabled:opacity-40 disabled:pointer-events-none"
          >
            Initialize Free Account
          </button>
          <p className="text-[10px] text-[#8a8a93] text-center leading-relaxed">
            Unlocks unlimited chat · 10 images/day · 5 videos/day · saved
            sessions · Memory Engine · cloud sync
          </p>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max === Infinity ? Math.min(100, value * 6) : Math.min(100, (value / max) * 100);
  return (
    <div>
      <div className="flex justify-between text-[11px] mb-1.5">
        <span className="text-[#8a8a93]">{label}</span>
        <span className="text-white/85 font-mono">
          {value}
          {max !== Infinity ? ` / ${max}` : " / ∞"}
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-white/8 overflow-hidden">
        <div
          className={`h-full rounded-full ${color} transition-all duration-700`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export default function ProfileScreen() {
  const {
    user,
    tier,
    signOut,
    model,
    setModel,
    personality,
    setPersonality,
    mode,
    setMode,
    focusMode,
    setFocusMode,
    replayOnboarding,
    usage,
    totals,
    streak,
    achievements,
    joinWaitlist,
    proWaitlist,
    setTab,
  } = useStore();
  const [auth, setAuth] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(localStorage.getItem("voice-enabled") === "true");

  useEffect(() => {
    localStorage.setItem("voice-enabled", voiceEnabled ? "true" : "false");
  }, [voiceEnabled]);

  const limits =
    tier === "guest"
      ? { chats: 10, images: 2, videos: 1 }
      : { chats: Infinity, images: 10, videos: 5 };

  const earned = achievements.filter((a) => a.earned).length;

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      {/* Identity card */}
      <div className="glass card-glow rounded-3xl p-5 mb-4 flex items-center gap-4">
        <div className="grad-icon w-16 h-16 rounded-full flex items-center justify-center shrink-0">
          <Logo size={36} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-lg font-bold leading-tight">
            {user ? user.name : "Operator"}
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className="text-[10px] rounded-full bg-white/6 border border-white/10 px-2.5 py-0.5 text-[#c9c9d1] font-mono">
              my-synex
            </span>
            <span className="text-[10px] rounded-full bg-emerald-400/10 border border-emerald-400/30 px-2.5 py-0.5 text-emerald-300 flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-emerald-400 pulse-dot" />
              online
            </span>
            <span
              className={`text-[10px] rounded-full px-2.5 py-0.5 border font-semibold ${
                tier === "guest"
                  ? "bg-white/6 border-white/15 text-[#c9c9d1]"
                  : "bg-purple-500/15 border-purple-400/40 text-purple-200"
              }`}
            >
              {tier === "guest" ? "🟢 Guest Mode" : "🔵 Free Account"}
            </span>
          </div>
        </div>
        {user ? (
          <button
            onClick={signOut}
            className="text-xs text-[#8a8a93] hover:text-white shrink-0"
          >
            Sign out
          </button>
        ) : (
          <button
            onClick={() => setAuth(true)}
            className="grad-btn rounded-full px-4 py-2 text-xs font-semibold shrink-0"
          >
            Sign up
          </button>
        )}
      </div>

      {/* Usage dashboard + streak */}
      <div className="grid md:grid-cols-3 grid-cols-1 gap-3 mb-4">
        <div className="glass rounded-2xl p-4 md:col-span-2 space-y-3">
          <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold">
            🚀 DAILY USAGE
          </div>
          <Stat label="Chat signals" value={usage.chats} max={limits.chats} color="bg-gradient-to-r from-purple-500 to-indigo-400" />
          <Stat label="Image renders" value={usage.images} max={limits.images} color="bg-gradient-to-r from-cyan-500 to-blue-400" />
          <Stat label="Video renders" value={usage.videos} max={limits.videos} color="bg-gradient-to-r from-pink-500 to-purple-400" />
          <div className="text-[10px] text-[#8a8a93] pt-1">
            Lifetime: {totals.chats} chats · {totals.images} images · {totals.videos} videos
          </div>
        </div>
        <div className="glass rounded-2xl p-4 flex flex-col items-center justify-center text-center">
          <IconFlame
            size={30}
            className={streak.count > 0 ? "text-orange-400 drop-shadow-[0_0_12px_rgba(251,146,60,0.7)]" : "text-[#8a8a93]"}
          />
          <div className="text-3xl font-bold mt-1">{streak.count}</div>
          <div className="text-[10px] tracking-[0.2em] text-[#8a8a93]">
            DAY STREAK
          </div>
        </div>
      </div>

      {/* Achievements */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold flex items-center gap-1.5">
            <IconTrophy size={14} className="text-amber-300" /> ACHIEVEMENTS
          </span>
          <span className="text-[11px] text-[#8a8a93] font-mono">
            {earned}/{achievements.length}
          </span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {achievements.map((a) => (
            <div
              key={a.id}
              title={`${a.label} — ${a.desc}`}
              className={`rounded-xl p-2.5 text-center border transition-all ${
                a.earned
                  ? "border-amber-400/30 bg-amber-400/8 shadow-[0_0_16px_rgba(251,191,36,0.12)]"
                  : "border-white/6 bg-white/3 opacity-40 grayscale"
              }`}
            >
              <div className="text-lg">{a.icon}</div>
              <div className="text-[8.5px] leading-tight text-white/80 mt-1 font-medium">
                {a.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Personality matrix */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
          PERSONALITY ENGINE
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {PERSONALITIES.map((p) => (
            <button
              key={p}
              onClick={() => setPersonality(p)}
              className={`rounded-xl py-2.5 text-[11.5px] font-semibold transition-all duration-300 border ${
                personality === p
                  ? "border-cyan-400/40 bg-cyan-400/12 text-cyan-200 shadow-[0_0_16px_rgba(34,211,238,0.15)]"
                  : "border-white/8 bg-white/3 text-[#8a8a93] hover:text-white hover:bg-white/8"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Default model */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
          DEFAULT MODEL
        </div>
        <div className="space-y-1.5">
          {MODELS.map((m) => (
            <button
              key={m.id}
              onClick={() => setModel(m.id)}
              className={`w-full flex items-center justify-between rounded-xl px-3.5 py-2.5 border transition-all ${
                model === m.id
                  ? "border-cyan-400/35 bg-cyan-400/8"
                  : "border-white/6 bg-white/3 hover:bg-white/8"
              }`}
            >
              <div className="text-left">
                <div className="text-[13px] font-semibold">{m.name}</div>
                <div className="text-[10px] text-[#8a8a93]">
                  {m.sub} · {m.vendor}
                </div>
              </div>
              {model === m.id && (
                <IconCheck size={17} className="text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.9)]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Voice Settings */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3 flex items-center gap-2">
          <IconMic size={14} className="text-cyan-300" /> VOICE MODE
        </div>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[13px] font-semibold">AI Voice Responses</div>
            <div className="text-[11px] text-[#8a8a93]">Read messages aloud in real-time</div>
          </div>
          <button
            onClick={() => setVoiceEnabled(!voiceEnabled)}
            className={`switch relative w-12 h-7 rounded-full shrink-0 ${
              voiceEnabled
                ? "bg-gradient-to-r from-purple-500 to-cyan-400"
                : "bg-white/12"
            }`}
          >
            <span
              className={`switch-knob absolute top-0.5 left-0.5 w-6 h-6 rounded-full bg-white shadow ${
                voiceEnabled ? "translate-x-5" : ""
              }`}
            />
          </button>
        </div>
      </div>

      {/* Answer Mode */}
      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
          ANSWER MODE
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {MODES.map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded-xl py-2.5 text-[10px] font-semibold transition-all duration-300 border ${
                mode === m
                  ? "border-purple-400/40 bg-purple-400/12 text-purple-200 shadow-[0_0_16px_rgba(168,85,247,0.15)]"
                  : "border-white/8 bg-white/3 text-[#8a8a93] hover:text-white hover:bg-white/8"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {/* System toggles */}
      <div className="glass rounded-2xl divide-y divide-white/6 mb-4">
        <div className="flex items-center justify-between p-4">
          <div>
            <div className="text-[13px] font-semibold">Focus Mode</div>
            <div className="text-[11px] text-[#8a8a93]">
              Collapses header + tabs for distraction-free work
            </div>
          </div>
          <button
            onClick={() => {
              setFocusMode(!focusMode);
              if (!focusMode) setTab("workspace");
            }}
            className={`switch relative w-12 h-7 rounded-full shrink-0 ${
              focusMode
                ? "bg-gradient-to-r from-purple-500 to-cyan-400"
                : "bg-white/12"
            }`}
          >
            <span
              className={`switch-knob absolute top-0.5 left-0.5 w-6 h-6 rounded-full bg-white shadow ${
                focusMode ? "translate-x-5" : ""
              }`}
            />
          </button>
        </div>
        <button
          onClick={replayOnboarding}
          className="w-full flex items-center justify-between p-4 hover:bg-white/4 transition-colors"
        >
          <div className="text-left">
            <div className="text-[13px] font-semibold">Replay Onboarding Tour</div>
            <div className="text-[11px] text-[#8a8a93]">Walk through Synex again</div>
          </div>
          <IconChevronRight size={16} className="text-[#8a8a93]" />
        </button>
      </div>

      {/* Plans */}
      <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3 px-1">
        ACCESS TIERS
      </div>
      <div className="grid md:grid-cols-3 grid-cols-1 gap-3 mb-6">
        {/* Guest */}
        <div
          className={`glass rounded-2xl p-4 ${tier === "guest" ? "border-emerald-400/30" : ""}`}
        >
          <div className="text-sm font-bold mb-1">🟢 Guest Mode</div>
          <div className="text-[10px] text-[#8a8a93] mb-3">No login needed</div>
          <ul className="text-[11px] text-white/70 space-y-1.5">
            <li>💬 10 chats/day</li>
            <li>🖼️ 2 images/day</li>
            <li>🎥 1 video/day</li>
            <li className="opacity-50">💾 No saved chats</li>
            <li className="opacity-50">🧠 No long-term memory</li>
          </ul>
          {tier === "guest" && (
            <div className="mt-3 text-[10px] text-emerald-300 font-semibold">
              ● CURRENT PLAN
            </div>
          )}
        </div>
        {/* Free */}
        <div
          className={`glass rounded-2xl p-4 ${
            tier === "free" ? "border-cyan-400/40 shadow-[0_0_24px_rgba(34,211,238,0.12)]" : ""
          }`}
        >
          <div className="text-sm font-bold mb-1">🔵 Free Account</div>
          <div className="text-[10px] text-[#8a8a93] mb-3">Sign up · $0</div>
          <ul className="text-[11px] text-white/70 space-y-1.5">
            <li>💬 Unlimited chats</li>
            <li>🖼️ 10 images/day</li>
            <li>🎥 5 videos/day</li>
            <li>💾 Saved conversations</li>
            <li>🧠 Memory Engine · ☁️ Sync</li>
          </ul>
          {tier === "free" ? (
            <div className="mt-3 text-[10px] text-cyan-300 font-semibold">
              ● CURRENT PLAN
            </div>
          ) : (
            <button
              onClick={() => setAuth(true)}
              className="grad-btn mt-3 w-full rounded-xl py-2 text-xs font-semibold"
            >
              Upgrade free
            </button>
          )}
        </div>
        {/* Pro */}
        <div className="rounded-2xl p-4 border border-purple-400/30 bg-gradient-to-b from-purple-500/12 to-transparent">
          <div className="text-sm font-bold mb-1">🟣 Synex Pro</div>
          <div className="text-[10px] text-purple-300 mb-3">Coming soon</div>
          <ul className="text-[11px] text-white/70 space-y-1.5">
            <li>⚡ Unlimited everything*</li>
            <li>🚀 Priority queue · faster responses</li>
            <li>🎨 Higher quality · longer videos</li>
            <li>🧠 Larger memory · multi-model</li>
            <li>👥 Team workspaces</li>
          </ul>
          <button
            onClick={joinWaitlist}
            disabled={proWaitlist}
            className={`mt-3 w-full rounded-xl py-2 text-xs font-semibold border transition-colors ${
              proWaitlist
                ? "border-purple-400/30 text-purple-300 bg-purple-500/10"
                : "border-purple-400/50 text-purple-200 hover:bg-purple-500/20"
            }`}
          >
            {proWaitlist ? "✓ On the waitlist" : "Join waitlist"}
          </button>
        </div>
      </div>

      <footer className="text-center text-[10px] text-[#8a8a93]/70 font-mono pb-4">
        MY SYNEX · build v2.4.1 · core:memory-engine · canvas:ready · ui:cyber-glass
      </footer>

      {auth && <SignUpModal onClose={() => setAuth(false)} />}
    </div>
  );
}
