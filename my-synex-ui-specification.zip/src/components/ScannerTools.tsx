import { useState, useRef, useEffect } from "react";

/* ---------- QR Scanner (jsQR, real client side decoding) ---------- */
function QRScanner() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);

  const start = async () => {
    setResult(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setScanning(true);
      tick();
    } catch {
      setResult("Camera access denied or unavailable.");
    }
  };

  const stop = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    cancelAnimationFrame(rafRef.current);
    setScanning(false);
  };

  const tick = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(tick);
      return;
    }
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    const jsQR = (await import("jsqr")).default;
    const code = jsQR(imageData.data, imageData.width, imageData.height);
    if (code) {
      setResult(code.data);
      stop();
      return;
    }
    rafRef.current = requestAnimationFrame(tick);
  };

  useEffect(() => () => stop(), []);

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-3">
        <span className="text-2xl">📱</span>
        <div>
          <h3 className="text-[14px] font-semibold">QR & Barcode Scanner</h3>
          <p className="text-[11px] text-[#8a8a93]">Live camera decoding</p>
        </div>
      </div>

      <div className="relative rounded-xl overflow-hidden bg-black aspect-video mb-3">
        <video ref={videoRef} className={`w-full h-full object-cover ${scanning ? "" : "hidden"}`} muted playsInline />
        <canvas ref={canvasRef} className="hidden" />
        {!scanning && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-[#8a8a93]">
            Camera preview will appear here
          </div>
        )}
        {scanning && (
          <div className="absolute inset-8 border-2 border-cyan-400/60 rounded-xl pointer-events-none" />
        )}
      </div>

      <button
        onClick={scanning ? stop : start}
        className={`w-full rounded-xl py-2.5 font-semibold text-sm ${scanning ? "bg-red-500/20 text-red-300" : "grad-btn"}`}
      >
        {scanning ? "⏹ Stop Scanning" : "📷 Start Scanning"}
      </button>

      {result && (
        <div className="mt-3 glass rounded-xl p-3 anim-pop">
          <div className="text-[10px] text-[#8a8a93] mb-1">DECODED RESULT</div>
          <p className="text-sm text-cyan-200 break-all">{result}</p>
        </div>
      )}
    </div>
  );
}

/* ---------- Document Scanner / OCR (Tesseract.js, real client side) ---------- */
function DocumentOCR() {
  const [image, setImage] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [progress, setProgress] = useState(0);
  const [running, setRunning] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImage(reader.result as string);
    reader.readAsDataURL(file);
    setText("");
  };

  const runOCR = async () => {
    if (!image) return;
    setRunning(true);
    setProgress(0);
    try {
      const Tesseract = await import("tesseract.js");
      const result = await Tesseract.recognize(image, "eng", {
        logger: (m: any) => {
          if (m.status === "recognizing text") {
            setProgress(Math.round(m.progress * 100));
          }
        },
      });
      setText(result.data.text.trim() || "No text detected in this image.");
    } catch {
      setText("OCR failed to process this image.");
    }
    setRunning(false);
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-3">
        <span className="text-2xl">📄</span>
        <div>
          <h3 className="text-[14px] font-semibold">Document Scanner & OCR</h3>
          <p className="text-[11px] text-[#8a8a93]">Extract text from any image, on device</p>
        </div>
      </div>

      <input type="file" accept="image/*" ref={fileRef} onChange={handleFile} className="hidden" />
      <button onClick={() => fileRef.current?.click()} className="w-full glass rounded-xl py-2.5 text-sm hover:bg-white/10 mb-3">
        📎 Upload Document Image
      </button>

      {image && (
        <div className="mb-3">
          <img src={image} alt="document" className="w-full rounded-xl max-h-48 object-contain bg-black/30" />
        </div>
      )}

      <button
        onClick={runOCR}
        disabled={!image || running}
        className="grad-btn w-full rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50"
      >
        {running ? `Extracting ${progress}%` : "🔎 Extract Text"}
      </button>

      {running && (
        <div className="h-1.5 rounded-full bg-white/8 overflow-hidden mt-3">
          <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-400 transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      )}

      {text && (
        <div className="mt-3 glass rounded-xl p-4 anim-pop max-h-56 overflow-y-auto">
          <div className="text-[10px] text-[#8a8a93] mb-1">EXTRACTED TEXT</div>
          <p className="text-sm text-white/85 whitespace-pre-line">{text}</p>
        </div>
      )}
    </div>
  );
}

export default function ScannerTools() {
  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="mb-5">
        <div className="text-[10px] tracking-[0.3em] text-amber-300/80 font-semibold mb-1">
          SCANNER TOOLS
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Camera Intelligence</h1>
      </div>
      <div className="space-y-4">
        <QRScanner />
        <DocumentOCR />
      </div>
    </div>
  );
}
