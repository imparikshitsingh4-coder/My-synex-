import { useState } from "react";
import { runAiTool } from "../data/aiTools";

/* ---------- Weather (Open-Meteo, keyless real-time) ---------- */
function WeatherTool() {
  const [city, setCity] = useState("");
  const [loading, setLoading] = useState(false);
  const [weather, setWeather] = useState<any>(null);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    if (!city.trim()) return;
    setLoading(true);
    setError("");
    try {
      const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`);
      const geo = await geoRes.json();
      if (!geo.results || geo.results.length === 0) {
        setError("City not found. Try another name.");
        setLoading(false);
        return;
      }
      const { latitude, longitude, name, country } = geo.results[0];
      const wRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto`);
      const w = await wRes.json();
      setWeather({ name, country, ...w });
    } catch {
      setError("Could not fetch live weather right now.");
    }
    setLoading(false);
  };

  const weatherIcon = (code: number) => {
    if (code === 0) return "☀️";
    if (code <= 3) return "⛅";
    if (code <= 48) return "🌫️";
    if (code <= 67) return "🌧️";
    if (code <= 77) return "❄️";
    if (code <= 82) return "🌦️";
    if (code <= 99) return "⛈️";
    return "🌤️";
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">🌤️</span>
        <div>
          <h3 className="text-[14px] font-semibold">Live Weather</h3>
          <p className="text-[11px] text-[#8a8a93]">Real time forecast, any city</p>
        </div>
      </div>
      <div className="flex gap-2 mb-3">
        <input
          value={city}
          onChange={(e) => setCity(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && fetchWeather()}
          placeholder="Enter city name..."
          className="flex-1 glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 focus:border-cyan-400/40"
        />
        <button onClick={fetchWeather} disabled={loading} className="grad-btn rounded-xl px-5 py-2.5 text-sm font-semibold disabled:opacity-50">
          {loading ? "..." : "Check"}
        </button>
      </div>
      {error && <p className="text-xs text-amber-300">{error}</p>}
      {weather && (
        <div className="glass rounded-xl p-4 anim-pop">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-sm font-semibold">{weather.name}, {weather.country}</div>
              <div className="text-[10px] text-[#8a8a93]">Live now</div>
            </div>
            <div className="text-3xl">{weatherIcon(weather.current.weather_code)}</div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-lg font-bold text-cyan-300">{Math.round(weather.current.temperature_2m)}°C</div>
              <div className="text-[9px] text-[#8a8a93]">TEMP</div>
            </div>
            <div>
              <div className="text-lg font-bold text-purple-300">{weather.current.relative_humidity_2m}%</div>
              <div className="text-[9px] text-[#8a8a93]">HUMIDITY</div>
            </div>
            <div>
              <div className="text-lg font-bold text-emerald-300">{Math.round(weather.current.wind_speed_10m)} km/h</div>
              <div className="text-[9px] text-[#8a8a93]">WIND</div>
            </div>
          </div>
          {weather.daily && (
            <div className="mt-3 pt-3 border-t border-white/10 flex justify-between text-xs">
              <span className="text-[#8a8a93]">Today: {Math.round(weather.daily.temperature_2m_min[0])}° / {Math.round(weather.daily.temperature_2m_max[0])}°</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------- Currency Converter (frankfurter.app, keyless real-time) ---------- */
function CurrencyTool() {
  const [amount, setAmount] = useState("100");
  const [from, setFrom] = useState("USD");
  const [to, setTo] = useState("EUR");
  const [result, setResult] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const currencies = ["USD", "EUR", "GBP", "JPY", "INR", "AUD", "CAD", "CHF", "CNY", "BRL", "MXN", "ZAR", "SGD", "AED", "KRW"];

  const convert = async () => {
    setLoading(true);
    try {
      const res = await fetch(`https://api.frankfurter.app/latest?amount=${amount}&from=${from}&to=${to}`);
      const data = await res.json();
      setResult(data.rates[to]);
    } catch {
      setResult(null);
    }
    setLoading(false);
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">💱</span>
        <div>
          <h3 className="text-[14px] font-semibold">Currency Converter</h3>
          <p className="text-[11px] text-[#8a8a93]">Live exchange rates</p>
        </div>
      </div>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 mb-2"
      />
      <div className="flex items-center gap-2 mb-3">
        <select value={from} onChange={(e) => setFrom(e.target.value)} className="flex-1 glass rounded-xl px-3 py-2.5 text-sm bg-white/5 border border-white/10 outline-none">
          {currencies.map((c) => <option key={c} value={c} className="bg-[#0a0a0f]">{c}</option>)}
        </select>
        <span className="text-[#8a8a93]">→</span>
        <select value={to} onChange={(e) => setTo(e.target.value)} className="flex-1 glass rounded-xl px-3 py-2.5 text-sm bg-white/5 border border-white/10 outline-none">
          {currencies.map((c) => <option key={c} value={c} className="bg-[#0a0a0f]">{c}</option>)}
        </select>
      </div>
      <button onClick={convert} disabled={loading} className="grad-btn w-full rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50">
        {loading ? "Converting..." : "Convert Live"}
      </button>
      {result !== null && (
        <div className="mt-3 glass rounded-xl p-4 text-center anim-pop">
          <div className="text-xl font-bold text-emerald-300">{result.toFixed(2)} {to}</div>
          <div className="text-[10px] text-[#8a8a93]">{amount} {from} today</div>
        </div>
      )}
    </div>
  );
}

/* ---------- Language Translator (MyMemory, keyless real-time) ---------- */
function TranslatorTool() {
  const [text, setText] = useState("");
  const [targetLang, setTargetLang] = useState("es");
  const [translated, setTranslated] = useState("");
  const [loading, setLoading] = useState(false);
  const langs = [
    { code: "es", name: "Spanish" }, { code: "fr", name: "French" }, { code: "de", name: "German" },
    { code: "ja", name: "Japanese" }, { code: "zh", name: "Chinese" }, { code: "hi", name: "Hindi" },
    { code: "ar", name: "Arabic" }, { code: "pt", name: "Portuguese" }, { code: "ru", name: "Russian" },
    { code: "ko", name: "Korean" }, { code: "it", name: "Italian" }, { code: "nl", name: "Dutch" },
  ];

  const translate = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${targetLang}`);
      const data = await res.json();
      setTranslated(data.responseData.translatedText);
    } catch {
      setTranslated("Translation unavailable right now.");
    }
    setLoading(false);
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">🌐</span>
        <div>
          <h3 className="text-[14px] font-semibold">Language Translator</h3>
          <p className="text-[11px] text-[#8a8a93]">Real time translation</p>
        </div>
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type English text to translate..."
        rows={2}
        className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 resize-none mb-2"
      />
      <select value={targetLang} onChange={(e) => setTargetLang(e.target.value)} className="w-full glass rounded-xl px-3 py-2.5 text-sm bg-white/5 border border-white/10 outline-none mb-3">
        {langs.map((l) => <option key={l.code} value={l.code} className="bg-[#0a0a0f]">{l.name}</option>)}
      </select>
      <button onClick={translate} disabled={loading} className="grad-btn w-full rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50">
        {loading ? "Translating..." : "Translate"}
      </button>
      {translated && (
        <div className="mt-3 glass rounded-xl p-4 anim-pop">
          <p className="text-sm text-cyan-200">{translated}</p>
        </div>
      )}
    </div>
  );
}

/* ---------- Barcode / Food Lookup (Open Food Facts, keyless real-time) ---------- */
function BarcodeLookupTool() {
  const [barcode, setBarcode] = useState("");
  const [loading, setLoading] = useState(false);
  const [product, setProduct] = useState<any>(null);
  const [error, setError] = useState("");

  const lookup = async () => {
    if (!barcode.trim()) return;
    setLoading(true);
    setError("");
    setProduct(null);
    try {
      const res = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode.trim()}.json`);
      const data = await res.json();
      if (data.status === 1) {
        setProduct(data.product);
      } else {
        setError("Product not found for this barcode.");
      }
    } catch {
      setError("Lookup failed. Check the barcode and try again.");
    }
    setLoading(false);
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">📦</span>
        <div>
          <h3 className="text-[14px] font-semibold">Barcode & Nutrition Scanner</h3>
          <p className="text-[11px] text-[#8a8a93]">Real product database lookup</p>
        </div>
      </div>
      <div className="flex gap-2 mb-3">
        <input
          value={barcode}
          onChange={(e) => setBarcode(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && lookup()}
          placeholder="Enter barcode number (e.g. 737628064502)"
          className="flex-1 glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10"
        />
        <button onClick={lookup} disabled={loading} className="grad-btn rounded-xl px-5 py-2.5 text-sm font-semibold disabled:opacity-50">
          {loading ? "..." : "Scan"}
        </button>
      </div>
      {error && <p className="text-xs text-amber-300">{error}</p>}
      {product && (
        <div className="glass rounded-xl p-4 flex gap-3 anim-pop">
          {product.image_front_small_url && (
            <img src={product.image_front_small_url} alt={product.product_name} className="w-16 h-16 rounded-lg object-cover" />
          )}
          <div className="flex-1">
            <div className="text-sm font-semibold">{product.product_name || "Unknown product"}</div>
            <div className="text-[10px] text-[#8a8a93] mb-1">{product.brands}</div>
            {product.nutriscore_grade && (
              <span className="text-[10px] rounded-full bg-emerald-400/10 border border-emerald-400/30 text-emerald-300 px-2 py-0.5">
                Nutri-Score {product.nutriscore_grade.toUpperCase()}
              </span>
            )}
            {product.nutriments && (
              <div className="text-[10px] text-[#8a8a93] mt-1.5">
                {product.nutriments["energy-kcal_100g"] ? `${product.nutriments["energy-kcal_100g"]} kcal/100g` : ""}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Generic AI research module (travel, local recs, shopping, navigation, landmark, plant/animal ID) ---------- */
function AIResearchTool({ icon, title, desc, placeholder, systemPrompt, prefix }: { icon: string; title: string; desc: string; placeholder: string; systemPrompt: string; prefix: string }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");

  const run = async () => {
    const val = input.trim() || placeholder;
    setLoading(true);
    const text = await runAiTool({ id: title, title, icon, desc, category: "intelligence", placeholder, systemPrompt, promptPrefix: prefix }, val);
    setResult(text);
    setLoading(false);
  };

  return (
    <div className="glass card-glow rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">{icon}</span>
        <div>
          <h3 className="text-[14px] font-semibold">{title}</h3>
          <p className="text-[11px] text-[#8a8a93]">{desc}</p>
        </div>
      </div>
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder={placeholder}
        rows={2}
        className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 resize-none mb-3"
      />
      <button onClick={run} disabled={loading} className="grad-btn w-full rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50">
        {loading ? "Researching..." : "Ask Synex"}
      </button>
      {result && (
        <div className="mt-3 glass rounded-xl p-4 anim-pop">
          <p className="text-sm text-white/85 leading-relaxed whitespace-pre-line">{result}</p>
        </div>
      )}
    </div>
  );
}

const AI_RESEARCH_TOOLS = [
  { icon: "✈️", title: "Travel Planner", desc: "Plan your perfect trip", placeholder: "5 days in Bali on a mid range budget", systemPrompt: "Create a detailed day by day travel itinerary with activities, food spots, and rough costs.", prefix: "Plan a trip: " },
  { icon: "📍", title: "Local Recommendations", desc: "Discover nearby gems", placeholder: "Best coffee shops in Brooklyn", systemPrompt: "Give specific, realistic local recommendations with a short reason for each pick.", prefix: "Recommend: " },
  { icon: "🛍️", title: "Shopping Comparison", desc: "Compare products smartly", placeholder: "iPhone 15 vs Samsung Galaxy S24", systemPrompt: "Compare these products fairly across price, features, and value, then give a recommendation for different types of buyers.", prefix: "Compare these products: " },
  { icon: "🧭", title: "AI Navigation", desc: "Get route guidance", placeholder: "Best way to get from downtown to the airport during rush hour", systemPrompt: "Give practical navigation advice including route options, timing, and tips to avoid delays.", prefix: "Help me navigate: " },
  { icon: "🏛️", title: "Landmark Explainer", desc: "Learn about any landmark", placeholder: "The Eiffel Tower", systemPrompt: "Explain the history, significance, and interesting facts about this landmark in an engaging way.", prefix: "Tell me about this landmark: " },
  { icon: "🌿", title: "Plant Identifier", desc: "Describe to identify plants", placeholder: "Green leaves with white edges, purple small flowers, grows in shade", systemPrompt: "Based on this description, suggest the most likely plant species and care tips.", prefix: "Identify this plant from the description: " },
  { icon: "🐾", title: "Animal Identifier", desc: "Describe to identify animals", placeholder: "Small brown bird with a red chest seen in my garden in spring", systemPrompt: "Based on this description, suggest the most likely animal species and interesting facts about it.", prefix: "Identify this animal from the description: " },
];

export default function SmartWorldHub() {
  const [section, setSection] = useState<"utilities" | "explore">("utilities");

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="mb-4">
        <div className="text-[10px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-1">
          SMART WORLD
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Real Time Utilities</h1>
      </div>

      <div className="glass rounded-2xl p-1 grid grid-cols-2 gap-1 mb-5">
        <button
          onClick={() => setSection("utilities")}
          className={`rounded-xl py-2.5 text-sm font-semibold transition-all ${section === "utilities" ? "bg-gradient-to-r from-cyan-600/70 to-teal-600/70 text-white" : "text-[#8a8a93] hover:text-white"}`}
        >
          Live Utilities
        </button>
        <button
          onClick={() => setSection("explore")}
          className={`rounded-xl py-2.5 text-sm font-semibold transition-all ${section === "explore" ? "bg-gradient-to-r from-cyan-600/70 to-teal-600/70 text-white" : "text-[#8a8a93] hover:text-white"}`}
        >
          Explore & Discover
        </button>
      </div>

      {section === "utilities" ? (
        <div className="space-y-4 anim-fade">
          <WeatherTool />
          <CurrencyTool />
          <TranslatorTool />
          <BarcodeLookupTool />
        </div>
      ) : (
        <div className="space-y-4 anim-fade">
          {AI_RESEARCH_TOOLS.map((t) => (
            <AIResearchTool key={t.title} {...t} />
          ))}
        </div>
      )}
    </div>
  );
}
