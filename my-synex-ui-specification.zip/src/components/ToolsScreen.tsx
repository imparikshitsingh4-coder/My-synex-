import { useState } from "react";
import { useStore } from "../state/store";
import LiveWorldScreen from "./LiveWorldScreen";
import ExperimentLab from "./ExperimentLab";
import CourseGenerator from "./CourseGenerator";
import AIToolsHub from "./AIToolsHub";
import CreativeStudio from "./CreativeStudio";
import SmartWorldHub from "./SmartWorldHub";
import VoiceSuite from "./VoiceSuite";
import PrivacyCenter from "./PrivacyCenter";
import ScannerTools from "./ScannerTools";

const ROADMAP_STEPS = [
  { month: "Months 1-2", title: "Foundation", items: ["HTML, CSS, JavaScript basics", "Git & GitHub", "VS Code setup", "Build 3 static websites"] },
  { month: "Months 3-4", title: "Frontend", items: ["React fundamentals", "Component architecture", "State management", "Tailwind CSS / styling"] },
  { month: "Months 5-6", title: "Backend", items: ["Node.js & Express", "REST APIs", "PostgreSQL / MongoDB", "Authentication & security"] },
  { month: "Months 7-8", title: "Full Stack", items: ["Deploy to Vercel/Render", "CI/CD pipelines", "Testing (Jest, Cypress)", "Performance optimization"] },
  { month: "Months 9-10", title: "Advanced", items: ["TypeScript deeply", "Docker & Kubernetes", "GraphQL", "System design basics"] },
  { month: "Months 11-12", title: "Job Ready", items: ["Portfolio projects (5+)", "LeetCode patterns", "Mock interviews", "Apply to 100+ positions"] },
];

const HUB_CARDS = [
  { id: "intelligence", title: "Intelligence Hub", icon: "🧠", desc: "Think Deeper, Debate, SWOT, Risk Analysis & 15 more", color: "from-purple-500/20 to-indigo-500/20" },
  { id: "coding", title: "Code Studio", icon: "💻", desc: "Bug Hunter, Code Review, SQL, Docker & 15 more", color: "from-amber-500/20 to-orange-500/20" },
  { id: "creative", title: "Creative Studio", icon: "🎨", desc: "Logo, Poster, UI Design, Voiceover & more", color: "from-pink-500/20 to-rose-500/20" },
  { id: "world", title: "Live World", icon: "🌍", desc: "60+ countries with real time exploration", color: "from-emerald-500/20 to-cyan-500/20" },
  { id: "smart-world", title: "Smart World", icon: "🛰️", desc: "Weather, currency, translator, barcode & more", color: "from-cyan-500/20 to-teal-500/20" },
  { id: "scanner", title: "Scanner Tools", icon: "📷", desc: "QR scanner and document OCR", color: "from-amber-500/20 to-yellow-500/20" },
  { id: "voice", title: "Voice Suite", icon: "🎤", desc: "Voice notes, meetings, podcasts, search", color: "from-violet-500/20 to-purple-500/20" },
  { id: "privacy", title: "Privacy Center", icon: "🔒", desc: "Encrypted vault, memory control, backups", color: "from-emerald-500/20 to-green-500/20" },
  { id: "lab", title: "Experiment Lab", icon: "🧪", desc: "12 what-if scenario simulators", color: "from-purple-500/20 to-pink-500/20" },
  { id: "courses", title: "Course Generator", icon: "🎓", desc: "Instant 30-lesson courses with quizzes", color: "from-violet-500/20 to-indigo-500/20" },
  { id: "planner", title: "Future Planner", icon: "🎯", desc: "12-month roadmap with progress tracking", color: "from-purple-500/20 to-blue-500/20" },
  { id: "dashboard", title: "Life Dashboard", icon: "📊", desc: "Track goals, habits, and projects", color: "from-emerald-500/20 to-green-500/20" },
  { id: "debate", title: "AI Debate Mode", icon: "⚔️", desc: "Structured debate on any topic", color: "from-red-500/20 to-pink-500/20" },
  { id: "tutor", title: "AI Tutor", icon: "📚", desc: "Personalized teaching, adaptive difficulty", color: "from-violet-500/20 to-indigo-500/20" },
];

const HABITS = [
  { id: 1, label: "Code for 1 hour", emoji: "💻" },
  { id: 2, label: "Read tech article", emoji: "📖" },
  { id: 3, label: "Solve 1 algorithm", emoji: "🧩" },
  { id: 4, label: "Ship something", emoji: "🚀" },
  { id: 5, label: "Learn new concept", emoji: "🧠" },
];

export default function ToolsScreen() {
  const { setTab, sendMessage } = useStore();
  const [tool, setTool] = useState<string | null>(null);
  const [habits, setHabits] = useState(HABITS.map((h) => ({ ...h, done: false })));
  const [goals] = useState([
    { id: 1, label: "Complete React course", progress: 65 },
    { id: 2, label: "Build portfolio site", progress: 30 },
    { id: 3, label: "Learn TypeScript", progress: 10 },
  ]);

  const toggleHabit = (id: number) => {
    setHabits((prev) => prev.map((h) => (h.id === id ? { ...h, done: !h.done } : h)));
  };

  if (tool === "world") return <LiveWorldScreen />;
  if (tool === "lab") return <ExperimentLab />;
  if (tool === "courses") return <CourseGenerator />;
  if (tool === "intelligence") return <><BackBtn onBack={() => setTool(null)} /><AIToolsHub initialCategory="intelligence" /></>;
  if (tool === "coding") return <><BackBtn onBack={() => setTool(null)} /><AIToolsHub initialCategory="coding" /></>;
  if (tool === "creative") return <><BackBtn onBack={() => setTool(null)} /><CreativeStudio /></>;
  if (tool === "smart-world") return <><BackBtn onBack={() => setTool(null)} /><SmartWorldHub /></>;
  if (tool === "scanner") return <><BackBtn onBack={() => setTool(null)} /><ScannerTools /></>;
  if (tool === "voice") return <><BackBtn onBack={() => setTool(null)} /><VoiceSuite /></>;
  if (tool === "privacy") return <><BackBtn onBack={() => setTool(null)} /><PrivacyCenter /></>;

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      {!tool ? (
        <div className="anim-fade">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="text-[10px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-1">
                SYNEX TOOLS
              </div>
              <h1 className="text-2xl font-bold tracking-tight">Power Suite</h1>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
            {HUB_CARDS.map((tc) => (
              <button
                key={tc.id}
                onClick={() => setTool(tc.id)}
                className="glass card-glow rounded-2xl p-4 text-left hover:bg-white/8 transition-all group"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${tc.color} flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform`}>
                  {tc.icon}
                </div>
                <div className="text-[13px] font-semibold mb-0.5">{tc.title}</div>
                <div className="text-[10px] text-[#8a8a93] leading-snug">{tc.desc}</div>
              </button>
            ))}
          </div>

          <div className="glass rounded-2xl p-4">
            <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">
              📊 TODAY'S OVERVIEW
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center">
                <div className="text-lg font-bold text-cyan-300">{habits.filter((h) => h.done).length}/{habits.length}</div>
                <div className="text-[10px] text-[#8a8a93]">Habits Done</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-purple-300">{Math.round(goals.reduce((a, g) => a + g.progress, 0) / goals.length)}%</div>
                <div className="text-[10px] text-[#8a8a93]">Avg Progress</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-emerald-300">{HUB_CARDS.length}</div>
                <div className="text-[10px] text-[#8a8a93]">Tools Available</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="anim-slide-up">
          <button onClick={() => setTool(null)} className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white mb-4">
            ← Back to Tools
          </button>

          {tool === "planner" && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">🎯</span>
                <div>
                  <div className="text-[10px] tracking-[0.3em] text-purple-300/80 font-semibold">FUTURE PLANNER</div>
                  <h2 className="text-xl font-bold">12-Month Roadmap</h2>
                </div>
              </div>
              <div className="space-y-3">
                {ROADMAP_STEPS.map((step, i) => (
                  <div key={step.month} className="glass rounded-2xl p-4 anim-slide-up" style={{ animationDelay: `${i * 0.1}s` }}>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-[10px] font-bold text-purple-300 bg-purple-500/15 px-2 py-1 rounded-full">{step.month}</span>
                      <h3 className="text-[14px] font-semibold">{step.title}</h3>
                    </div>
                    <ul className="space-y-1.5">
                      {step.items.map((item) => (
                        <li key={item} className="text-xs text-white/70 flex items-center gap-2">
                          <span className="w-1 h-1 rounded-full bg-cyan-400" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <button
                onClick={() => { setTool(null); setTab("workspace"); setTimeout(() => sendMessage("Help me become a software engineer in 12 months"), 200); }}
                className="grad-btn w-full rounded-2xl py-3 font-semibold text-sm mt-4"
              >
                Customize This Plan with AI
              </button>
            </div>
          )}

          {tool === "dashboard" && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">📊</span>
                <div>
                  <div className="text-[10px] tracking-[0.3em] text-emerald-300/80 font-semibold">LIFE DASHBOARD</div>
                  <h2 className="text-xl font-bold">Goals & Habits</h2>
                </div>
              </div>

              <div className="glass rounded-2xl p-4 mb-4">
                <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">DAILY HABITS</div>
                <div className="space-y-2">
                  {habits.map((h) => (
                    <button
                      key={h.id}
                      onClick={() => toggleHabit(h.id)}
                      className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all ${
                        h.done ? "bg-emerald-400/10 border border-emerald-400/30" : "bg-white/4 border border-white/8 hover:bg-white/8"
                      }`}
                    >
                      <span className={`w-5 h-5 rounded-lg flex items-center justify-center text-[10px] ${h.done ? "bg-emerald-400 text-black" : "bg-white/10 text-[#8a8a93]"}`}>
                        {h.done ? "✓" : h.emoji}
                      </span>
                      <span className={`text-[13px] ${h.done ? "text-emerald-200 line-through" : "text-white/80"}`}>{h.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="glass rounded-2xl p-4">
                <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] font-semibold mb-3">ACTIVE GOALS</div>
                <div className="space-y-3">
                  {goals.map((g) => (
                    <div key={g.id}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-white/80">{g.label}</span>
                        <span className="text-cyan-300 font-mono">{g.progress}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-white/8 overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-400 transition-all duration-700" style={{ width: `${g.progress}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tool === "debate" && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">⚔️</span>
                <div>
                  <div className="text-[10px] tracking-[0.3em] text-red-300/80 font-semibold">AI DEBATE MODE</div>
                  <h2 className="text-xl font-bold">Debate Arena</h2>
                </div>
              </div>
              <button
                onClick={() => { setTool(null); setTab("workspace"); setTimeout(() => sendMessage("Let's debate: Is AI beneficial for society? You take the opposing view."), 200); }}
                className="grad-btn w-full rounded-2xl py-3 font-semibold text-sm mb-3"
              >
                ⚔️ Start a Debate
              </button>
              <p className="text-xs text-[#8a8a93] text-center">Choose a topic and Synex will debate you with structured arguments, counterpoints, and evidence.</p>
            </div>
          )}

          {tool === "tutor" && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">🎓</span>
                <div>
                  <div className="text-[10px] tracking-[0.3em] text-violet-300/80 font-semibold">AI TUTOR</div>
                  <h2 className="text-xl font-bold">Personal Tutor</h2>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {["Mathematics", "Programming", "Science", "Languages", "History", "Art"].map((s) => (
                  <button
                    key={s}
                    onClick={() => { setTool(null); setTab("workspace"); setTimeout(() => sendMessage(`Teach me ${s.toLowerCase()} from scratch. Start with the basics.`), 200); }}
                    className="glass rounded-xl px-3 py-2.5 text-xs text-white/80 hover:bg-white/10 hover:text-cyan-200 transition-all text-left"
                  >
                    {s}
                  </button>
                ))}
              </div>
              <p className="text-xs text-[#8a8a93] text-center">Synex adapts difficulty based on your responses. Switch modes (Child, Beginner, Expert) for different teaching styles.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function BackBtn({ onBack }: { onBack: () => void }) {
  return (
    <div className="max-w-3xl w-full mx-auto px-4 pt-4">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-[#8a8a93] hover:text-white">
        ← Back to Tools
      </button>
    </div>
  );
}
