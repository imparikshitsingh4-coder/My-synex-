import { useState, useRef, useEffect } from "react";
import { useStore } from "../state/store";
import { runAiTool } from "../data/aiTools";

export default function VoiceSuite() {
  const { sendMessage } = useStore();
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [notes, setNotes] = useState<{ id: string; text: string; ts: number }[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("synex-voice-notes") || "[]");
    } catch {
      return [];
    }
  });
  const [meetingActive, setMeetingActive] = useState(false);
  const [meetingLog, setMeetingLog] = useState<string[]>([]);
  const [podcastScript, setPodcastScript] = useState("");
  const [podcastLoading, setPodcastLoading] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const recRef = useRef<any>(null);

  useEffect(() => {
    localStorage.setItem("synex-voice-notes", JSON.stringify(notes));
  }, [notes]);

  const startListening = (mode: "note" | "meeting" | "search") => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setTranscript("Voice recognition is not supported in this browser.");
      return;
    }
    const rec = new SR();
    recRef.current = rec;
    rec.lang = "en-US";
    rec.continuous = mode === "meeting";
    rec.interimResults = true;

    rec.onresult = (e: any) => {
      let finalText = "";
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalText += e.results[i][0].transcript + " ";
        else interim += e.results[i][0].transcript;
      }
      setTranscript(finalText || interim);
      if (mode === "meeting" && finalText) {
        setMeetingLog((prev) => [...prev, finalText.trim()]);
      }
      if (mode === "search" && finalText) {
        sendMessage(finalText.trim());
        rec.stop();
      }
    };

    rec.onend = () => {
      if (mode !== "meeting") setListening(false);
    };

    rec.start();
    setListening(true);
    if (mode === "meeting") setMeetingActive(true);
  };

  const stopListening = () => {
    recRef.current?.stop();
    setListening(false);
    setMeetingActive(false);
  };

  const saveNote = () => {
    if (!transcript.trim()) return;
    setNotes((prev) => [{ id: Math.random().toString(36).slice(2), text: transcript, ts: Date.now() }, ...prev]);
    setTranscript("");
  };

  const generatePodcast = async () => {
    if (!podcastScript.trim()) return;
    setPodcastLoading(true);
    const text = await runAiTool(
      { id: "podcast", title: "Podcast", icon: "🎙️", desc: "", category: "creative", placeholder: "", systemPrompt: "Write an engaging short podcast script segment with a natural conversational tone about this topic, as if a host is speaking directly to the listener.", promptPrefix: "Write a podcast segment about: " },
      podcastScript
    );
    setPodcastScript(text);
    setPodcastLoading(false);
  };

  const playScript = (text: string) => {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find((v) => v.lang.startsWith("en"));
    if (preferred) utter.voice = preferred;
    utter.onend = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="max-w-3xl w-full mx-auto px-4 py-5 flex-1 overflow-y-auto">
      <div className="mb-5">
        <div className="text-[10px] tracking-[0.3em] text-violet-300/80 font-semibold mb-1">
          VOICE SUITE
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Speak Naturally</h1>
      </div>

      {/* Voice Search */}
      <div className="glass card-glow rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🔍</span>
          <div>
            <h3 className="text-[14px] font-semibold">Voice Search</h3>
            <p className="text-[11px] text-[#8a8a93]">Speak a question, get it sent to Synex chat</p>
          </div>
        </div>
        <button
          onClick={() => startListening("search")}
          disabled={listening}
          className={`grad-btn w-full rounded-xl py-3 font-semibold text-sm disabled:opacity-50 ${listening ? "mic-live" : ""}`}
        >
          {listening ? "🎤 Listening..." : "🎤 Start Voice Search"}
        </button>
      </div>

      {/* Voice Notes */}
      <div className="glass card-glow rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">📝</span>
          <div>
            <h3 className="text-[14px] font-semibold">Voice Notes</h3>
            <p className="text-[11px] text-[#8a8a93]">Capture thoughts hands free</p>
          </div>
        </div>
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => (listening ? stopListening() : startListening("note"))}
            className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all ${listening ? "bg-red-500/20 text-red-300 mic-live" : "grad-btn"}`}
          >
            {listening ? "⏹ Stop Recording" : "🎤 Record Note"}
          </button>
          {transcript && !listening && (
            <button onClick={saveNote} className="glass rounded-xl px-4 py-2.5 text-sm hover:bg-white/10">
              Save
            </button>
          )}
        </div>
        {transcript && (
          <div className="glass rounded-xl p-3 text-sm text-cyan-200 mb-2">{transcript}</div>
        )}
        {notes.length > 0 && (
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {notes.map((n) => (
              <div key={n.id} className="glass rounded-xl p-3 flex items-start justify-between gap-2">
                <p className="text-xs text-white/80 flex-1">{n.text}</p>
                <button onClick={() => setNotes((prev) => prev.filter((x) => x.id !== n.id))} className="text-[#8a8a93] hover:text-red-300 text-xs shrink-0">✕</button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Meeting Recorder */}
      <div className="glass card-glow rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🗣️</span>
          <div>
            <h3 className="text-[14px] font-semibold">Meeting Recorder</h3>
            <p className="text-[11px] text-[#8a8a93]">Continuous live transcription</p>
          </div>
        </div>
        <button
          onClick={() => (meetingActive ? stopListening() : startListening("meeting"))}
          className={`w-full rounded-xl py-2.5 text-sm font-semibold transition-all mb-3 ${meetingActive ? "bg-red-500/20 text-red-300 mic-live" : "grad-btn"}`}
        >
          {meetingActive ? "⏹ End Meeting" : "🎙️ Start Meeting Recording"}
        </button>
        {meetingLog.length > 0 && (
          <div className="glass rounded-xl p-3 max-h-40 overflow-y-auto space-y-1.5">
            {meetingLog.map((line, i) => (
              <p key={i} className="text-xs text-white/75 leading-relaxed">{line}</p>
            ))}
          </div>
        )}
      </div>

      {/* Podcast / Audiobook */}
      <div className="glass card-glow rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🎧</span>
          <div>
            <h3 className="text-[14px] font-semibold">AI Podcast & Audiobook</h3>
            <p className="text-[11px] text-[#8a8a93]">Generate and listen to spoken content</p>
          </div>
        </div>
        <textarea
          value={podcastScript}
          onChange={(e) => setPodcastScript(e.target.value)}
          placeholder="Type a topic, e.g. the history of coffee..."
          rows={3}
          className="w-full glass rounded-xl px-4 py-2.5 text-sm outline-none bg-white/5 border border-white/10 resize-none mb-3"
        />
        <div className="flex gap-2">
          <button onClick={generatePodcast} disabled={podcastLoading} className="grad-btn flex-1 rounded-xl py-2.5 font-semibold text-sm disabled:opacity-50">
            {podcastLoading ? "Writing..." : "✍️ Generate Script"}
          </button>
          <button onClick={() => playScript(podcastScript)} disabled={!podcastScript.trim() || speaking} className="glass rounded-xl px-4 py-2.5 text-sm hover:bg-white/10 disabled:opacity-50">
            {speaking ? "🔊" : "▶ Play"}
          </button>
        </div>
      </div>
    </div>
  );
}
