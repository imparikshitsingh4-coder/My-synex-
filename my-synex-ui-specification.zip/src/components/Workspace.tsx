import { useEffect, useRef, useState } from "react";
import { MODELS, useStore, type AnswerMode } from "../state/store";
import Logo from "./Logo";
import {
  IconBolt,
  IconSplit,
  IconExpand,
  IconChevronDown,
  IconCheck,
  IconMic,
  IconClip,
  IconSliders,
  IconArrowUp,
  IconX,
  IconChevronRight,
} from "./icons";

const MODES: AnswerMode[] = ["Short", "Detailed", "Expert", "Beginner", "Child"];

const TEMPLATES = [
  "Help me become a software engineer in 12 months",
  "Show me a demo dashboard HTML",
  "Explain quantum computing like I'm 5",
  "Debate: Should AI be regulated?",
  "Debug this: const x = undefined + 5",
  "Generate a logo for a coffee shop",
  "Plan a trip to Japan for 2 weeks",
  "Write a Python script to scrape prices",
];

/* ---------- Canvas artifact: demo dashboard ---------- */
function CanvasDashboard() {
  const bars = [42, 68, 35, 80, 58, 90, 66, 74, 51, 88, 70, 95];
  return (
    <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#07070c] anim-pop">
      <div className="flex items-center gap-1.5 px-3 py-2 bg-white/5 border-b border-white/10">
        <span className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
        <span className="w-2.5 h-2.5 rounded-full bg-yellow-400/80" />
        <span className="w-2.5 h-2.5 rounded-full bg-green-400/80" />
        <span className="ml-2 text-[10px] text-[#8a8a93] font-mono">
          artifact://demo-dashboard.html
        </span>
      </div>
      <div className="p-4 space-y-3">
        <div className="grid grid-cols-3 gap-2">
          {[
            ["UPTIME", "99.98%", "text-cyan-300"],
            ["REQ/S", "1,284", "text-purple-300"],
            ["LATENCY", "42ms", "text-emerald-300"],
          ].map(([k, v, c]) => (
            <div key={k} className="glass rounded-xl p-2.5">
              <div className="text-[9px] tracking-widest text-[#8a8a93]">{k}</div>
              <div className={`text-sm font-bold ${c}`}>{v}</div>
            </div>
          ))}
        </div>
        <div className="glass rounded-xl p-3">
          <div className="text-[9px] tracking-widest text-[#8a8a93] mb-2">
            THROUGHPUT · LIVE
          </div>
          <div className="flex items-end gap-1 h-20">
            {bars.map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t bg-gradient-to-t from-purple-600/60 to-cyan-400/80"
                style={{ height: `${h}%`, transition: "height .6s ease", transitionDelay: `${i * 40}ms` }}
              />
            ))}
          </div>
        </div>
        <div className="glass rounded-xl p-3 font-mono text-[10px] space-y-1.5">
          <div className="text-emerald-300">✓ synex.core — memory engine synced</div>
          <div className="text-cyan-300">→ canvas.render(artifact#0x2f)… ok</div>
          <div className="text-[#8a8a93]">· awaiting next signal</div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Code Editor Canvas ---------- */
function CanvasCode({ code }: { code: string }) {
  const [preview, setPreview] = useState(true);
  const [codeText, setCodeText] = useState(code || `<!DOCTYPE html>
<html>
<head>
  <style>
    body { background: #0a0a0f; color: white; font-family: sans-serif; padding: 2rem; }
    h1 { color: #22d3ee; }
    .card { background: rgba(255,255,255,0.05); border-radius: 12px; padding: 1.5rem; margin-top: 1rem; }
  </style>
</head>
<body>
  <h1>Hello from Synex Canvas</h1>
  <div class="card">
    <p>Edit code here → Live preview updates instantly.</p>
  </div>
</body>
</html>`);

  return (
    <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#07070c] anim-pop flex flex-col h-full">
      <div className="flex items-center gap-1.5 px-3 py-2 bg-white/5 border-b border-white/10">
        <span className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
        <span className="w-2.5 h-2.5 rounded-full bg-yellow-400/80" />
        <span className="w-2.5 h-2.5 rounded-full bg-green-400/80" />
        <div className="flex-1" />
        <button
          onClick={() => setPreview(!preview)}
          className={`text-[10px] font-semibold px-3 py-1 rounded-full border transition-colors ${
            preview
              ? "border-cyan-400/40 text-cyan-300 bg-cyan-400/10"
              : "border-white/15 text-[#8a8a93]"
          }`}
        >
          {preview ? "Preview" : "Code"}
        </button>
      </div>
      {preview ? (
        <iframe
          srcDoc={codeText}
          className="flex-1 w-full bg-[#07070c] border-0"
          title="preview"
          sandbox="allow-scripts"
        />
      ) : (
        <textarea
          value={codeText}
          onChange={(e) => setCodeText(e.target.value)}
          className="flex-1 w-full bg-[#07070c] text-[13px] font-mono p-4 outline-none resize-none text-green-300"
          spellCheck={false}
        />
      )}
    </div>
  );
}

/* ---------- Model bottom sheet ---------- */
function ModelSheet({ onClose }: { onClose: () => void }) {
  const { model, setModel } = useStore();
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm anim-fade" />
      <div
        className="relative w-full max-w-md glass-strong rounded-t-3xl p-5 pb-8 anim-sheet"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold tracking-widest text-[#8a8a93]">
            SELECT ENGINE
          </h3>
          <button onClick={onClose} className="text-[#8a8a93] hover:text-white p-1">
            <IconX size={18} />
          </button>
        </div>
        <div className="space-y-2">
          {MODELS.map((m) => {
            const active = m.id === model;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setModel(m.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between rounded-2xl px-4 py-3.5 border transition-all ${
                  active
                    ? "border-cyan-400/40 bg-cyan-400/10 shadow-[0_0_24px_rgba(34,211,238,0.15)]"
                    : "border-white/8 bg-white/4 hover:bg-white/8"
                }`}
              >
                <div className="text-left">
                  <div className="text-[15px] font-semibold">{m.name}</div>
                  <div className="text-xs text-[#8a8a93]">
                    {m.sub} · {m.vendor}
                  </div>
                </div>
                {active && (
                  <IconCheck
                    size={20}
                    className="text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.9)]"
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------- Emotion indicator ---------- */
function EmotionIndicator() {
  const { emotion } = useStore();
  
  const emotions = {
    happy: { color: "cyan", icon: "😊", label: "Happy" },
    working: { color: "purple", icon: "⚡", label: "Working" },
    researching: { color: "orange", icon: "🔍", label: "Researching" },
    generating: { color: "pink", icon: "✨", label: "Creating" },
    neutral: { color: "gray", icon: "●", label: "Ready" },
  };
  
  const e = emotions[emotion];
  
  return (
    <div className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition-all emotion-${emotion}`}>
      <span className="animate-pulse">{e.icon}</span>
      <span className={emotion === "happy" ? "text-cyan-300" : emotion === "working" ? "text-purple-300" : emotion === "researching" ? "text-orange-300" : emotion === "generating" ? "text-pink-300" : "text-gray-300"}>
        {e.label}
      </span>
    </div>
  );
}

/* ---------- Cinematic message ---------- */
function CinematicMessage({ message, mode }: { message: { role: string; text: string; artifact?: string | null }; mode: string }) {
  // Simplified - just show the message with entrance animation
  return (
    <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-[14px] leading-relaxed whitespace-pre-wrap dramatic-entrance ${
      message.role === "user"
        ? "bg-gradient-to-br from-purple-600/80 to-indigo-600/80 text-white rounded-br-md"
        : "glass text-white/90 rounded-bl-md"
    }`}>
      {message.role === "ai" && (
        <div className="text-[10px] tracking-widest text-cyan-300/80 mb-1.5 font-semibold">
          {mode} MODE
        </div>
      )}
      {message.text}
    </div>
  );
}

/* ---------- Main workspace ---------- */
export default function Workspace() {
  const {
    messages,
    sendMessage,
    aiTyping,
    model,
    turns,
    personality,
    focusMode,
    setFocusMode,
    canChat,
    chatsLeft,
    tier,
    setTab,
    mode,
    setMode,
    emotion,
    setEmotion,
  } = useStore();

  const [input, setInput] = useState("");
  const [sheet, setSheet] = useState(false);
  const [split, setSplit] = useState(false);
  const [listening, setListening] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [showCodeCanvas, setShowCodeCanvas] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const recRef = useRef<any>(null);
  const speechRef = useRef<any>(null);

  const modelInfo = MODELS.find((m) => m.id === model)!;
  const hasArtifact = messages.some((m) => m.artifact === "dashboard");
  const hasCode = messages.some((m) => m.text.toLowerCase().includes("html") || m.text.toLowerCase().includes("code") || m.text.toLowerCase().includes("css") || m.text.toLowerCase().includes("javascript"));
  const showCanvas = split || hasArtifact || showCodeCanvas;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, aiTyping]);

  // Update emotion based on AI state
  useEffect(() => {
    if (aiTyping) {
      setEmotion("researching");
    } else if (emotion === "researching") {
      setEmotion("happy");
    }
  }, [aiTyping, emotion, setEmotion]);

  const send = (text?: string) => {
    const t = (text ?? input).trim();
    if (!t) return;
    setEmotion("working");
    sendMessage(t);
    setInput("");
    if (t.toLowerCase().includes("code") || t.toLowerCase().includes("html") || t.toLowerCase().includes("css") || t.toLowerCase().includes("javascript")) {
      setShowCodeCanvas(true);
    }
    // Reset emotion after response
    setTimeout(() => setEmotion("happy"), 1000);
  };

  const toggleMic = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (listening) {
      recRef.current?.stop();
      window.speechSynthesis.cancel();
      setListening(false);
      return;
    }
    if (!SR) {
      setListening(true);
      setTimeout(() => {
        setInput("Tell me something interesting");
        setListening(false);
      }, 1500);
      return;
    }
    const rec = new SR();
    recRef.current = rec;
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.onresult = (e: any) => {
      let interim = "";
      let final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setInput(final || interim);
      if (final) {
        setTimeout(() => send(final), 300);
      }
    };
    rec.onend = () => setListening(false);
    rec.start();
    setListening(true);
  };

  // AI Voice synthesis
  useEffect(() => {
    if (!aiTyping && messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg?.role === "ai" && lastMsg.text) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(lastMsg.text);
        utter.rate = 1.1;
        utter.pitch = 1;
        const voices = window.speechSynthesis.getVoices();
        const preferred = voices.find((v) => v.lang.startsWith("en") && v.name.includes("Google")) || voices.find((v) => v.lang.startsWith("en"));
        if (preferred) utter.voice = preferred;
        speechRef.current = utter;
        if (localStorage.getItem("voice-enabled") === "true") {
          window.speechSynthesis.speak(utter);
        }
      }
    }
    return () => { window.speechSynthesis.cancel(); };
  }, [messages.length, aiTyping]);

  const fullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      {!focusMode && (
        <header className="px-4 pt-4 pb-2 max-w-5xl w-full mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Logo size={34} className="drop-shadow-[0_0_12px_rgba(139,92,246,0.7)]" />
              <div>
                <h1 className="text-[17px] font-bold leading-tight tracking-tight">
                  My Synex
                </h1>
                <p className="text-[11px] text-[#8a8a93]">
                  Canvas Ready · {personality} Mode
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSplit((v) => !v)}
                className={`p-2 rounded-xl transition-colors ${
                  split ? "text-cyan-300 bg-cyan-400/10" : "text-[#8a8a93] hover:text-white hover:bg-white/5"
                }`}
                title="Split pane"
              >
                <IconSplit size={19} />
              </button>
              <button
                onClick={fullscreen}
                className="p-2 rounded-xl text-[#8a8a93] hover:text-white hover:bg-white/5 transition-colors"
                title="Full screen"
              >
                <IconExpand size={19} />
              </button>
            </div>
          </div>

          {/* Context ribbon */}
          <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
            <button
              onClick={() => setSheet(true)}
              className="shrink-0 flex items-center gap-1.5 rounded-full border border-purple-400/30 bg-purple-500/15 px-3.5 py-1.5 text-xs font-semibold text-purple-200 hover:bg-purple-500/25 transition-colors"
            >
              {modelInfo.name}
              <IconChevronDown size={13} />
            </button>
            <span className="shrink-0 flex items-center gap-1.5 rounded-full border border-cyan-400/25 bg-cyan-400/8 px-3.5 py-1.5 text-xs text-cyan-200">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-300 pulse-dot" />
              Memory Engine
            </span>
            <span className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-[#c9c9d1]">
              {turns} turns
            </span>
            <span className="shrink-0 flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/8 px-3.5 py-1.5 text-xs text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              {tier === "guest" ? "Guest" : "Synced"}
            </span>
            <span className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-[#c9c9d1]">
              Context Loaded
            </span>
            <EmotionIndicator />
            <button
              onClick={() => setTab("tools")}
              className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-[#c9c9d1] hover:bg-white/10"
            >
              🛠 Tools
            </button>
          </div>

          {/* Mode selector */}
          <div className="flex gap-1 mt-2 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
            {MODES.map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`shrink-0 rounded-full px-3 py-1 text-[10px] font-semibold transition-all ${
                  mode === m
                    ? "bg-gradient-to-r from-purple-500/40 to-cyan-400/30 text-white border border-cyan-400/30"
                    : "border border-white/10 text-[#8a8a93] hover:text-white"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </header>
      )}

      {focusMode && (
        <button
          onClick={() => setFocusMode(false)}
          className="fixed top-4 right-4 z-50 glass rounded-full px-4 py-2 text-xs text-cyan-300 hover:bg-white/10"
        >
          Exit Focus
        </button>
      )}

      {/* Body */}
      <div
        className={`flex-1 min-h-0 max-w-5xl w-full mx-auto px-4 pt-2 pb-3 grid gap-3 ${
          showCanvas ? "md:grid-cols-2 grid-cols-1" : "grid-cols-1"
        }`}
      >
        {/* Chat pane */}
        <div className="flex flex-col min-h-0 overflow-y-auto">
          {messages.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center px-6 py-10">
              <IconBolt
                size={96}
                strokeWidth={1.2}
                className="text-cyan-300 bolt-glow mb-7 floaty"
              />
              <h2 className="text-lg font-semibold mb-2">
                Canvas Ready. Awaiting Input.
              </h2>
              <p className="text-sm text-[#8a8a93] max-w-xs leading-relaxed mb-6">
                Ask anything. Request HTML/JS artifacts and Synex will render
                them in the Canvas.
              </p>
              
              {/* Templates */}
              <button
                onClick={() => setTemplatesOpen(!templatesOpen)}
                className="flex items-center gap-2 text-xs text-purple-300 hover:text-purple-200 mb-3"
              >
                <IconChevronRight size={14} className={`transition-transform ${templatesOpen ? "rotate-90" : ""}`} />
                {templatesOpen ? "Hide Templates" : "Show Workspace Templates"}
              </button>
              
              {templatesOpen && (
                <div className="grid grid-cols-2 gap-2 w-full max-w-sm anim-fade">
                  {TEMPLATES.slice(0, 8).map((t) => (
                    <button
                      key={t}
                      onClick={() => send(t)}
                      className="text-left glass rounded-xl px-3 py-2.5 text-[11px] text-white/80 hover:bg-white/10 hover:text-cyan-200 transition-all"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3 py-2">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <CinematicMessage message={m} mode={mode} />
                  {m.artifact === "dashboard" && (
                    <div className="mt-3 md:hidden">
                      <CanvasDashboard />
                    </div>
                  )}
                </div>
              ))}
              {aiTyping && (
                <div className="flex justify-start anim-fade">
                  <div className="glass rounded-2xl rounded-bl-md px-4 py-3.5 flex gap-1.5">
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="w-1.5 h-1.5 rounded-full bg-cyan-300 typing-dot"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </div>
                </div>
              )}
              <div ref={endRef} />
            </div>
          )}
        </div>

        {/* Canvas pane (desktop) */}
        {showCanvas && (
          <div className="hidden md:flex flex-col min-h-0 overflow-y-auto glass rounded-2xl p-3">
            <div className="text-[10px] tracking-[0.25em] text-[#8a8a93] mb-2 px-1">
              CANVAS {hasCode ? "· CODE" : "· RENDER"}
            </div>
            {hasCode ? (
              <CanvasCode code="" />
            ) : hasArtifact ? (
              <CanvasDashboard />
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-[#8a8a93] text-center px-6">
                Canvas idle — request an HTML artifact and it renders here.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Input dock */}
      <div className="max-w-5xl w-full mx-auto px-4 pb-3">
        {!canChat && (
          <div className="mb-2 glass rounded-2xl px-4 py-3 text-xs text-amber-300/90 flex items-center justify-between anim-fade">
            <span>Guest limit reached (10 signals/day).</span>
            <button
              onClick={() => setTab("profile")}
              className="text-cyan-300 font-semibold hover:underline shrink-0 ml-3"
            >
              Sign up free →
            </button>
          </div>
        )}
        {tier === "guest" && canChat && chatsLeft <= 5 && (
          <div className="mb-2 text-[11px] text-[#8a8a93] px-2">
            {chatsLeft} guest signals left today
          </div>
        )}

        <div className="glass-strong rounded-3xl flex items-center gap-1 pl-2.5 pr-2 py-2 card-glow">
          <button
            onClick={toggleMic}
            className={`p-2 rounded-full transition-colors ${
              listening
                ? "text-red-400 bg-red-500/15 mic-live"
                : "text-[#8a8a93] hover:text-white"
            }`}
            title="Voice input"
          >
            <IconMic size={18} />
          </button>
          <button className="p-2 rounded-full text-[#8a8a93] hover:text-white transition-colors" title="Attach">
            <IconClip size={18} />
          </button>
          <button
            onClick={() => setTab("profile")}
            className="p-2 rounded-full text-[#8a8a93] hover:text-white transition-colors"
            title="Tuning"
          >
            <IconSliders size={18} />
          </button>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder={listening ? "Listening…" : "Send a signal to Synex..."}
            disabled={!canChat}
            className="flex-1 bg-transparent outline-none text-[14px] placeholder:text-[#8a8a93]/70 px-1 min-w-0 disabled:opacity-50"
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || !canChat}
            className="grad-btn w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-40 disabled:pointer-events-none shrink-0"
            title="Send"
          >
            <IconArrowUp size={18} className="text-white" strokeWidth={2.4} />
          </button>
        </div>
      </div>

      {sheet && <ModelSheet onClose={() => setSheet(false)} />}
    </div>
  );
}
