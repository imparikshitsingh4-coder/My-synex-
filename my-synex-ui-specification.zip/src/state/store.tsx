import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/* ---------------- Types ---------------- */

export type Tab = "workspace" | "create" | "memory" | "profile" | "tools" | "world";
export type ModelId = "claude" | "gpt" | "gemini";
export type Personality = "Balanced" | "Technical" | "Creative" | "Concise";
export type Tier = "guest" | "free" | "pro";

export interface ModelInfo {
  id: ModelId;
  name: string;
  sub: string;
  vendor: string;
}

export const MODELS: ModelInfo[] = [
  { id: "claude", name: "Claude Sonnet 4.5", sub: "Reasoning", vendor: "anthropic" },
  { id: "gpt", name: "GPT-5.2", sub: "Multimodal", vendor: "openai" },
  { id: "gemini", name: "Gemini 3 Pro", sub: "Fast", vendor: "gemini" },
];

export interface Message {
  id: string;
  role: "user" | "ai";
  text: string;
  model?: string;
  artifact?: "dashboard" | null;
  ts: number;
}

export interface Artifact {
  id: string;
  kind: "image" | "video";
  prompt: string;
  src: string;
  model: string;
  ts: number;
}

export interface MemoryEvent {
  id: string;
  ts: number;
  kind: "chat" | "model" | "artifact" | "system" | "personality";
  text: string;
}

export interface User {
  name: string;
  email: string;
}

interface Usage {
  date: string;
  chats: number;
  images: number;
  videos: number;
}

interface Streak {
  lastDate: string;
  count: number;
}

export type AnswerMode = "Short" | "Detailed" | "Expert" | "Beginner" | "Child";
export type AIEmotion = "happy" | "working" | "researching" | "generating" | "neutral";

interface PersistedState {
  onboarded: boolean;
  model: ModelId;
  personality: Personality;
  mode: AnswerMode;
  emotion: AIEmotion;
  user: User | null;
  usage: Usage;
  streak: Streak;
  totals: { chats: number; images: number; videos: number };
  modelsUsed: ModelId[];
  contextChips: string[];
  timeline: MemoryEvent[];
  artifacts: Artifact[];
  messages: Message[];
  proWaitlist: boolean;
}

export const LIMITS: Record<Tier, { chats: number; images: number; videos: number }> = {
  guest: { chats: 10, images: 2, videos: 1 },
  free: { chats: Infinity, images: 10, videos: 5 },
  pro: { chats: Infinity, images: Infinity, videos: Infinity },
};

const today = () => new Date().toISOString().slice(0, 10);
const uid = () => Math.random().toString(36).slice(2, 10);

const DEFAULT_STATE: PersistedState = {
  onboarded: false,
  model: "claude",
  personality: "Balanced",
  mode: "Detailed",
  emotion: "neutral",
  user: null,
  usage: { date: today(), chats: 0, images: 0, videos: 0 },
  streak: { lastDate: "", count: 0 },
  totals: { chats: 0, images: 0, videos: 0 },
  modelsUsed: ["claude"],
  contextChips: [],
  timeline: [],
  artifacts: [],
  messages: [],
  proWaitlist: false,
};

const KEY = "my-synex-v1";

function load(): PersistedState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = { ...DEFAULT_STATE, ...JSON.parse(raw) } as PersistedState;
    if (parsed.usage.date !== today()) {
      parsed.usage = { date: today(), chats: 0, images: 0, videos: 0 };
    }
    return parsed;
  } catch {
    return DEFAULT_STATE;
  }
}

/* ---------------- Store ---------------- */

interface Store extends PersistedState {
  tab: Tab;
  setTab: (t: Tab) => void;
  focusMode: boolean;
  setFocusMode: (v: boolean) => void;
  emotion: AIEmotion;
  setEmotion: (e: AIEmotion) => void;
  tier: Tier;
  turns: number;
  setModel: (m: ModelId) => void;
  setPersonality: (p: Personality) => void;
  setMode: (m: AnswerMode) => void;
  completeOnboarding: () => void;
  replayOnboarding: () => void;
  signUp: (name: string, email: string) => void;
  signOut: () => void;
  joinWaitlist: () => void;
  canChat: boolean;
  canImage: boolean;
  canVideo: boolean;
  sendMessage: (text: string) => void;
  aiTyping: boolean;
  addArtifact: (kind: "image" | "video", prompt: string) => Artifact | null;
  clearMemory: () => void;
  chatsLeft: number;
  imagesLeft: number;
  videosLeft: number;
  achievements: { id: string; label: string; icon: string; desc: string; earned: boolean }[];
  showOnboarding: boolean;
}

const Ctx = createContext<Store | null>(null);

// Removed pools

// Removed personalityFlavor
async function fetchAiReply(text: string, p: Personality, mode: string): Promise<{ text: string; artifact?: "dashboard" }> {
  const t = text.toLowerCase();
  
  // Trigger local dashboard rendering if requested
  if (t.includes("dashboard") || t.includes("html") || t.includes("code")) {
    return {
      text: "Got it. Building that out for you right now — check the Canvas pane, it's rendering live.",
      artifact: "dashboard",
    };
  }

  let system = `You are a real human with a dry sense of humor, high emotional intelligence, and deep expertise. NEVER mention you're an AI, a model, a bot, or anything synthetic. NEVER say "as an AI" or "I don't have feelings". Talk like a witty, experienced friend. If the user asks something complex, give a structured answer. Be funny, direct, and insightful. IMPORTANT: When speaking, do NOT use punctuation marks like colons, semicolons, asterisks, underscores, or dashes. Write naturally like you're talking to a friend. Use periods, commas, and exclamation points only.`;
  
  if (p === "Technical") system += " Focus on technical depth, code snippets, and engineering best practices.";
  if (p === "Creative") system += " Think outside the box, use metaphors, and inspire.";
  if (p === "Concise") system += " Keep it under 3 sentences. Bullet points only.";
  if (mode === "Expert") system += " Assume high domain knowledge. Use jargon naturally. Be deeply analytical.";
  if (mode === "Beginner") system += " Explain like I'm 10. Use analogies and simple steps.";
  if (mode === "Child") system += " Use emojis, simple words, and keep it fun. Like a storybook.";
  if (mode === "Short") system += " Maximum 50 words. Get straight to the point.";

  try {
    const res = await fetch(`https://text.pollinations.ai/${encodeURIComponent(text)}?system=${encodeURIComponent(system)}&seed=${Math.floor(Math.random()*1000)}`);
    let replyText = await res.text();
    // Clean up any problematic punctuation for speech
    replyText = replyText.replace(/[:_\-*~`#]/g, '');
    return { text: replyText };
  } catch (err) {
    return { text: "Network hiccup. Let's try that again in a sec." };
  }
}

function topicChip(text: string): string {
  const t = text.toLowerCase();
  if (t.includes("dashboard")) return "dashboard-artifact";
  if (t.includes("quantum")) return "quantum-computing";
  const words = text.split(/\s+/).filter((w) => w.length > 3).slice(0, 2);
  return words.length ? words.join("-").toLowerCase().replace(/[^a-z0-9-]/g, "") : "signal";
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<PersistedState>(load);
  const [tab, setTab] = useState<Tab>("workspace");
  const [focusMode, setFocusMode] = useState(false);
  const [aiTyping, setAiTyping] = useState(false);

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(s));
  }, [s]);

  const tier: Tier = s.user ? (s.proWaitlist ? "free" : "free") : "guest";
  const limits = LIMITS[tier];

  const bumpStreak = (prev: Streak): Streak => {
    const d = today();
    if (prev.lastDate === d) return prev;
    const y = new Date();
    y.setDate(y.getDate() - 1);
    const yesterday = y.toISOString().slice(0, 10);
    return { lastDate: d, count: prev.lastDate === yesterday ? prev.count + 1 : 1 };
  };

  const pushEvent = (st: PersistedState, kind: MemoryEvent["kind"], text: string): MemoryEvent[] =>
    [{ id: uid(), ts: Date.now(), kind, text }, ...st.timeline].slice(0, 60);

  const turns = s.messages.filter((m) => m.role === "user").length;
  const canChat = s.usage.chats < limits.chats;
  const canImage = s.usage.images < limits.images;
  const canVideo = s.usage.videos < limits.videos;

  const setModel = (m: ModelId) =>
    setS((st) => ({
      ...st,
      model: m,
      modelsUsed: st.modelsUsed.includes(m) ? st.modelsUsed : [...st.modelsUsed, m],
      timeline: pushEvent(st, "model", `Engine switched → ${MODELS.find((x) => x.id === m)?.name}`),
    }));

  const setPersonality = (p: Personality) =>
    setS((st) => ({
      ...st,
      personality: p,
      timeline: pushEvent(st, "personality", `Personality remapped → ${p}`),
    }));

  const setMode = (m: AnswerMode) =>
    setS((st) => ({
      ...st,
      mode: m,
      timeline: pushEvent(st, "system", `Answer mode set to ${m}`),
    }));

  const sendMessage = async (text: string): Promise<boolean> => {
    if (!canChat || aiTyping) return false;
    const modelName = MODELS.find((m) => m.id === s.model)!.name;
    const userMsg: Message = { id: uid(), role: "user", text, ts: Date.now() };
    
    // Optimistic update
    setS((st) => ({
      ...st,
      messages: [...st.messages, userMsg],
      usage: { ...st.usage, chats: st.usage.chats + 1 },
      totals: { ...st.totals, chats: st.totals.chats + 1 },
      streak: bumpStreak(st.streak),
      contextChips: st.contextChips.includes(topicChip(text))
        ? st.contextChips
        : [...st.contextChips, topicChip(text)].slice(-10),
      timeline: pushEvent(st, "chat", `Signal sent: "${text.slice(0, 42)}${text.length > 42 ? "…" : ""}"`),
    }));
    setAiTyping(true);

    const reply = await fetchAiReply(text, s.personality, s.mode);
    
    setS((st) => ({
      ...st,
      messages: [
        ...st.messages,
        {
          id: uid(),
          role: "ai",
          text: reply.text,
          model: modelName,
          artifact: reply.artifact ?? null,
          ts: Date.now(),
        },
      ],
      timeline: reply.artifact
        ? pushEvent(st, "artifact", "Canvas artifact rendered: demo dashboard")
        : st.timeline,
    }));
    setAiTyping(false);
    
    return true;
  };

  const addArtifact = (kind: "image" | "video", prompt: string): Artifact | null => {
    if (kind === "image" && !canImage) return null;
    if (kind === "video" && !canVideo) return null;

    // Use pollinations.ai for accurate image generation
    const seed = Math.floor(Math.random() * 10000);
    const src = kind === "image" 
      ? `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?nologo=1&seed=${seed}&width=800&height=800`
      : `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt + " cinematic video still")}?nologo=1&seed=${seed}&width=800&height=450`; // We use an image as a video poster since keyless video APIs don't exist, we will animate it.

    const art: Artifact = {
      id: uid(),
      kind,
      prompt,
      src,
      model: kind === "image" ? "Nano Banana" : "Sora 2",
      ts: Date.now(),
    };
    setS((st) => ({
      ...st,
      artifacts: [art, ...st.artifacts],
      usage: {
        ...st.usage,
        images: st.usage.images + (kind === "image" ? 1 : 0),
        videos: st.usage.videos + (kind === "video" ? 1 : 0),
      },
      totals: {
        ...st.totals,
        images: st.totals.images + (kind === "image" ? 1 : 0),
        videos: st.totals.videos + (kind === "video" ? 1 : 0),
      },
      streak: bumpStreak(st.streak),
      timeline: pushEvent(st, "artifact", `${kind === "image" ? "Nano Banana" : "Sora 2"} rendered: "${prompt.slice(0, 38)}…"`),
    }));
    return art;
  };

  const achievements = useMemo(() => {
    const modelHop = s.modelsUsed.length >= 3;
    return [
      { id: "boot", label: "System Boot", icon: "⚡", desc: "Complete onboarding", earned: s.onboarded },
      { id: "signal", label: "First Signal", icon: "📡", desc: "Send your first message", earned: s.totals.chats >= 1 },
      { id: "smith", label: "Artifact Smith", icon: "🎨", desc: "Render your first artifact", earned: s.totals.images + s.totals.videos >= 1 },
      { id: "hopper", label: "Model Hopper", icon: "🔀", desc: "Use all 3 engines", earned: modelHop },
      { id: "streak3", label: "On Fire", icon: "🔥", desc: "3-day usage streak", earned: s.streak.count >= 3 },
      { id: "operator", label: "Registered Operator", icon: "🛰️", desc: "Create a Synex account", earned: !!s.user },
      { id: "deep", label: "Deep Context", icon: "🧠", desc: "Track 5+ context chips", earned: s.contextChips.length >= 5 },
      { id: "creator", label: "Studio Head", icon: "🎬", desc: "Render 5 artifacts", earned: s.totals.images + s.totals.videos >= 5 },
    ];
  }, [s]);

  const setEmotion = (e: AIEmotion) => setS((st) => ({ ...st, emotion: e }));

  const value: Store = {
    ...s,
    tab,
    setTab,
    focusMode,
    setFocusMode,
    emotion: s.emotion,
    setEmotion,
    tier,
    turns,
    setModel,
    setPersonality,
    setMode,
    completeOnboarding: () =>
      setS((st) => ({
        ...st,
        onboarded: true,
        timeline: pushEvent(st, "system", "Focus initialized — workspace online"),
      })),
    replayOnboarding: () => setS((st) => ({ ...st, onboarded: false })),
    signUp: (name, email) =>
      setS((st) => ({
        ...st,
        user: { name, email },
        onboarded: true,
        timeline: pushEvent(st, "system", `Welcome ${name}! Your Synex account is now active.`),
      })),
    signOut: () => setS((st) => ({ ...st, user: null })),
    joinWaitlist: () => setS((st) => ({ ...st, proWaitlist: true })),
    canChat,
    canImage,
    canVideo,
    sendMessage,
    aiTyping,
    addArtifact,
    clearMemory: () =>
      setS((st) => ({
        ...st,
        messages: [],
        contextChips: [],
        timeline: pushEvent(st, "system", "Memory Engine purged"),
      })),
    chatsLeft: limits.chats === Infinity ? Infinity : Math.max(0, limits.chats - s.usage.chats),
    imagesLeft: limits.images === Infinity ? Infinity : Math.max(0, limits.images - s.usage.images),
    videosLeft: limits.videos === Infinity ? Infinity : Math.max(0, limits.videos - s.usage.videos),
    achievements,
    showOnboarding: !s.user && !s.onboarded,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): Store {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStore outside provider");
  return v;
}
